package com.example.smartsy.Traffic;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TrafficApi {
    @GET("api/traffic/1.0/traffic_level")
    Call<TrafficData> getTrafficLevel(
            @Query("lat") double latitude,
            @Query("lon") double longitude,
            @Query("radius") int radius,
            @Query("key") String apiKey
    );
}