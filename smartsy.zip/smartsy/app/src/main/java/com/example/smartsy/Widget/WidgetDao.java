package com.example.smartsy.Widget;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;

import java.util.List;

@Dao
public interface WidgetDao {
    @Insert
    void insert(WidgetEntity widget);

    @Query("SELECT * FROM widgets ORDER BY timestamp DESC")  // Теперь timestamp есть
    List<WidgetEntity> getAllWidgets();

    @Delete
    void delete(WidgetEntity widget);

    @Query("DELETE FROM widgets")
    void deleteAll();

    @Query("SELECT * FROM widgets WHERE id = :id")
    WidgetEntity getWidgetById(int id);
}