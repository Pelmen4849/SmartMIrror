package com.example.smartsy;

import retrofit2.Call;
import retrofit2.http.GET;

public interface CurrencyApi {
    @GET("daily_json.js")
    Call<CurrencyData> getCurrencyRates();
}