package com.example.smartsy.Weather;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class WeatherData {
    @SerializedName("main")
    private Main main;

    @SerializedName("weather")
    private Weather[] weather;

    @SerializedName("name")
    private String cityName;

    @SerializedName("wind")
    private Wind wind;

    @SerializedName("dt")
    private long timestamp;

    public static class Main {
        @SerializedName("temp")
        private double temp;

        @SerializedName("feels_like")
        private double feelsLike;

        @SerializedName("humidity")
        private int humidity;

        @SerializedName("pressure")
        private int pressure;

        public double getTemp() { return temp; }
        public double getFeelsLike() { return feelsLike; }
        public int getHumidity() { return humidity; }
        public int getPressure() { return pressure; }
    }

    public static class Weather {
        @SerializedName("description")
        private String description;

        @SerializedName("icon")
        private String icon;

        @SerializedName("main")
        private String main;

        public String getDescription() { return description; }
        public String getIcon() { return icon; }
        public String getMain() { return main; }
    }

    public static class Wind {
        @SerializedName("speed")
        private double speed;

        @SerializedName("deg")
        private int direction;

        public double getSpeed() { return speed; }
        public int getDirection() { return direction; }
    }

    // Класс для прогноза
    public static class ForecastResponse {
        @SerializedName("list")
        private List<ForecastItem> list;

        @SerializedName("city")
        private City city;

        public List<ForecastItem> getList() { return list; }
        public City getCity() { return city; }
    }

    public static class ForecastItem {
        @SerializedName("dt")
        private long timestamp;

        @SerializedName("main")
        private Main main;

        @SerializedName("weather")
        private List<Weather> weather;

        @SerializedName("wind")
        private Wind wind;

        @SerializedName("dt_txt")
        private String dateText;

        public long getTimestamp() { return timestamp; }
        public Main getMain() { return main; }
        public List<Weather> getWeather() { return weather; }
        public Wind getWind() { return wind; }
        public String getDateText() { return dateText; }
    }

    public static class City {
        @SerializedName("name")
        private String name;

        @SerializedName("country")
        private String country;

        public String getName() { return name; }
        public String getCountry() { return country; }
    }

    public Main getMain() { return main; }
    public Weather[] getWeather() { return weather; }
    public String getCityName() { return cityName; }
    public Wind getWind() { return wind; }
    public long getTimestamp() { return timestamp; }
}