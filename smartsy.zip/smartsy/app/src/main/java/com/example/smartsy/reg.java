package com.example.smartsy;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class reg extends AppCompatActivity {

    private TextInputEditText emailEditText, passwordEditText, confirmPasswordEditText;
    private TextInputLayout emailLayout, passwordLayout, confirmPasswordLayout;
    private Button registerButton;
    private ProgressBar progressBar;
    private TextView errorTextView;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reg);

        mAuth = FirebaseAuth.getInstance();

        initViews();
        setupListeners();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initViews() {
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);

        emailLayout = findViewById(R.id.emailLayout);
        passwordLayout = findViewById(R.id.passwordLayout);
        confirmPasswordLayout = findViewById(R.id.confirmPasswordLayout);

        registerButton = findViewById(R.id.registerButton);
        progressBar = findViewById(R.id.progressBar);
        errorTextView = findViewById(R.id.errorTextView);
    }

    private void setupListeners() {
        registerButton.setOnClickListener(v -> attemptRegistration());

        emailEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                clearErrors();
            }
        });

        passwordEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                clearErrors();
            }
        });

        confirmPasswordEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                clearErrors();
            }
        });
    }

    private void attemptRegistration() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String confirmPassword = confirmPasswordEditText.getText().toString().trim();

        if (validateInput(email, password, confirmPassword)) {
            registerUser(email, password);
        }
    }

    private boolean validateInput(String email, String password, String confirmPassword) {
        boolean isValid = true;

        if (TextUtils.isEmpty(email)) {
            emailLayout.setError("Введите email");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailLayout.setError("Введите корректный email");
            isValid = false;
        } else {
            emailLayout.setError(null);
        }

        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError("Введите пароль");
            isValid = false;
        } else if (password.length() < 6) {
            passwordLayout.setError("Пароль должен содержать минимум 6 символов");
            isValid = false;
        } else {
            passwordLayout.setError(null);
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            confirmPasswordLayout.setError("Подтвердите пароль");
            isValid = false;
        } else if (!password.equals(confirmPassword)) {
            confirmPasswordLayout.setError("Пароли не совпадают");
            isValid = false;
        } else {
            confirmPasswordLayout.setError(null);
        }

        return isValid;
    }

    private void registerUser(String email, String password) {
        showLoading(true);
        clearErrors();

        if (mAuth == null) {
            mAuth = FirebaseAuth.getInstance();
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    showLoading(false);

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            user.sendEmailVerification()
                                    .addOnCompleteListener(emailTask -> {
                                        if (emailTask.isSuccessful()) {
                                            Toast.makeText(reg.this,
                                                    "Регистрация успешна! Проверьте email для подтверждения.",
                                                    Toast.LENGTH_LONG).show();
                                        }
                                    });

                            navigateToMainActivity();
                        }
                    } else {
                        String errorMessage = "Ошибка регистрации";
                        if (task.getException() != null) {
                            errorMessage = getErrorMessage(task.getException().getMessage());
                        }
                        showError(errorMessage);
                    }
                });
    }

    private String getErrorMessage(String firebaseError) {
        if (firebaseError.contains("email address is already in use")) {
            return "Этот email уже зарегистрирован";
        } else if (firebaseError.contains("invalid email")) {
            return "Неверный формат email";
        } else if (firebaseError.contains("password is too weak")) {
            return "Пароль слишком простой";
        } else if (firebaseError.contains("network error")) {
            return "Ошибка сети. Проверьте подключение";
        }
        return "Ошибка регистрации. Попробуйте еще раз";
    }

    private void showLoading(boolean isLoading) {
        if (isLoading) {
            progressBar.setVisibility(View.VISIBLE);
            registerButton.setEnabled(false);
            registerButton.setAlpha(0.5f);
        } else {
            progressBar.setVisibility(View.GONE);
            registerButton.setEnabled(true);
            registerButton.setAlpha(1f);
        }
    }

    private void showError(String message) {
        errorTextView.setText(message);
        errorTextView.setVisibility(View.VISIBLE);
    }

    private void clearErrors() {
        errorTextView.setVisibility(View.GONE);
        errorTextView.setText("");
        emailLayout.setError(null);
        passwordLayout.setError(null);
        confirmPasswordLayout.setError(null);
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(reg.this, add_vidgets.class);
        startActivity(intent);
        finish();
    }

    // НЕТ метода onStart() здесь!
}