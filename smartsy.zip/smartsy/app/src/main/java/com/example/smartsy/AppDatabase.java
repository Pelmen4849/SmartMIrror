package com.example.smartsy;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.smartsy.Widget.WidgetDao;
import com.example.smartsy.Widget.WidgetEntity;

@Database(entities = {WidgetEntity.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    abstract WidgetDao widgetDao();
}