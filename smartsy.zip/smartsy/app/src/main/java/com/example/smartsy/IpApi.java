package com.example.smartsy;

import com.example.smartsy.Weather.IpLocation;

import retrofit2.Call;
import retrofit2.http.GET;

public interface IpApi {
    @GET("json/")
    Call<IpLocation> getLocationByIp();
}