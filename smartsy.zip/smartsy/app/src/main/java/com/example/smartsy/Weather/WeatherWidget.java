package com.example.smartsy.Weather;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.RemoteViews;

import com.example.smartsy.R;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeatherWidget extends AppWidgetProvider {

    private static final String TAG = "WeatherWidget";
    private static final String OWM_ICON_URL = "https://openweathermap.org/img/wn/%s@2x.png";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Log.d(TAG, "onUpdate called");
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Загружаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String city = prefs.getString("weather_city", "Город не указан");
        String temp = prefs.getString("weather_temp", "0°C");
        String desc = prefs.getString("weather_description", "Обновите данные");
        String icon = prefs.getString("weather_icon", "01d");
        String windSpeed = prefs.getString("weather_wind", "0 м/с");
        long lastUpdate = prefs.getLong("last_weather_update", 0);

        // Данные прогноза
        String forecast1Time = prefs.getString("forecast_1_time", "--:--");
        String forecast1Temp = prefs.getString("forecast_1_temp", "--");
        String forecast1Icon = prefs.getString("forecast_1_icon", "01d");

        String forecast2Time = prefs.getString("forecast_2_time", "--:--");
        String forecast2Temp = prefs.getString("forecast_2_temp", "--");
        String forecast2Icon = prefs.getString("forecast_2_icon", "01d");

        String forecast3Time = prefs.getString("forecast_3_time", "--:--");
        String forecast3Temp = prefs.getString("forecast_3_temp", "--");
        String forecast3Icon = prefs.getString("forecast_3_icon", "01d");

        Log.d("WeatherWidget", "Загружены данные: " + city + ", " + temp + ", " + desc);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.weather_widget_layout);

        // Устанавливаем текущие данные
        views.setTextViewText(R.id.widget_city, city);
        views.setTextViewText(R.id.widget_temp, temp);
        views.setTextViewText(R.id.widget_desc, desc);
        views.setTextViewText(R.id.widget_wind, "Ветер: " + windSpeed);

        // Загружаем иконку текущей погоды
        String iconUrl = String.format(OWM_ICON_URL, icon);
        try {
            Picasso.get().load(iconUrl).into(views, R.id.widget_icon, new int[]{appWidgetId});
        } catch (Exception e) {
            Log.e("WeatherWidget", "Ошибка загрузки иконки: " + e.getMessage());
        }

        // Устанавливаем данные прогноза
        views.setTextViewText(R.id.forecast_time_1, forecast1Time);
        views.setTextViewText(R.id.forecast_temp_1, forecast1Temp);

        views.setTextViewText(R.id.forecast_time_2, forecast2Time);
        views.setTextViewText(R.id.forecast_temp_2, forecast2Temp);

        views.setTextViewText(R.id.forecast_time_3, forecast3Time);
        views.setTextViewText(R.id.forecast_temp_3, forecast3Temp);

        // Загружаем иконки прогноза
        try {
            Picasso.get().load(String.format(OWM_ICON_URL, forecast1Icon))
                    .into(views, R.id.forecast_icon_1, new int[]{appWidgetId});
            Picasso.get().load(String.format(OWM_ICON_URL, forecast2Icon))
                    .into(views, R.id.forecast_icon_2, new int[]{appWidgetId});
            Picasso.get().load(String.format(OWM_ICON_URL, forecast3Icon))
                    .into(views, R.id.forecast_icon_3, new int[]{appWidgetId});
        } catch (Exception e) {
            Log.e("WeatherWidget", "Ошибка загрузки иконок прогноза: " + e.getMessage());
        }

        // Форматируем время обновления
        String updateTime = "Обновлено: " + getFormattedTime(lastUpdate);
        views.setTextViewText(R.id.widget_update_time, updateTime);

        // Добавляем интент для обновления по клику
        Intent updateIntent = new Intent(context, WeatherWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = {appWidgetId};
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.widget_container, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);

        Log.d("WeatherWidget", "Виджет обновлен");
    }

    private static String getFormattedTime(long timestamp) {
        if (timestamp == 0) return "никогда";

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    @Override
    public void onEnabled(Context context) {
        Log.d(TAG, "Первый виджет добавлен");
    }

    @Override
    public void onDisabled(Context context) {
        Log.d(TAG, "Последний виджет удален");
    }
}