package com.example.smartsy;

import com.example.smartsy.Widget.WidgetItem;
import com.google.gson.Gson;

public class RemoteWidget {
    private String type;
    private String title;
    private String data;
    private String info;
    private long timestamp;

    public RemoteWidget(String type, String title, String data, String info) {
        this.type = type;
        this.title = title;
        this.data = data;
        this.info = info;
        this.timestamp = System.currentTimeMillis();
    }

    // Конструктор для WidgetItem из пакета com.example.smartsy.Widget
    public static RemoteWidget fromWidgetItem(com.example.smartsy.Widget.WidgetItem widget) {
        return new RemoteWidget(
                widget.getType(),
                widget.getTitle(),
                widget.getData(),
                widget.getAdditionalInfo()
        );
    }

    // Конструктор для локального WidgetItem (если он есть)
    public static RemoteWidget fromLocalWidgetItem(WidgetItem widget) {
        return new RemoteWidget(
                widget.getType(),
                widget.getTitle(),
                widget.getData(),
                widget.getAdditionalInfo()
        );
    }

    public String toJson() {
        return new Gson().toJson(this);
    }

    // Геттеры
    public String getType() { return type; }
    public String getTitle() { return title; }
    public String getData() { return data; }
    public String getInfo() { return info; }
    public long getTimestamp() { return timestamp; }
}