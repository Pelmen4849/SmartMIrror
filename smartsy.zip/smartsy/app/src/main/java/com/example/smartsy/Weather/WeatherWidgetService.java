package com.example.smartsy.Weather;

import android.content.Intent;
import android.widget.RemoteViewsService;

public class WeatherWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new WeatherWidgetFactory(getApplicationContext(), intent);
    }
}