package com.example.smartsy;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;

public class NoteWidget extends AppWidgetProvider {
    private static final String TAG = "NoteWidget";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateNoteWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateNoteWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String noteText = prefs.getString("note_text", "Ваша заметка");
        String backgroundColor = prefs.getString("note_background", "#000000");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.note_widget);

        // Устанавливаем данные
        views.setTextViewText(R.id.note_text, noteText);

        // Устанавливаем цвет фона для всего layout
        try {
            int color = Color.parseColor(backgroundColor);
            views.setInt(R.id.note_layout, "setBackgroundColor", color);

            // Меняем цвет текста в зависимости от фона для лучшей читаемости
            int textColor = getContrastColor(color);
            views.setTextColor(R.id.note_text, textColor);

        } catch (Exception e) {
            // Если цвет некорректный, используем черный фон и белый текст
            views.setInt(R.id.note_layout, "setBackgroundColor", Color.BLACK);
            views.setTextColor(R.id.note_text, Color.WHITE);
        }

        // Обработчик нажатия для обновления
        Intent updateIntent = new Intent(context, NoteWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});

        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.note_layout, updatePendingIntent);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Note Widget Updated: " + noteText);
    }

    @Override
    public void onEnabled(Context context) {
        android.util.Log.d(TAG, "Note Widget Enabled");
    }

    @Override
    public void onDisabled(Context context) {
        android.util.Log.d(TAG, "Note Widget Disabled");
    }

    // Статический метод для обновления виджета
    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String noteText = prefs.getString("note_text", "Ваша заметка");
        String backgroundColor = prefs.getString("note_background", "#000000");

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.note_widget);

        views.setTextViewText(R.id.note_text, noteText);

        try {
            int color = Color.parseColor(backgroundColor);
            views.setInt(R.id.note_layout, "setBackgroundColor", color);

            int textColor = getContrastColor(color);
            views.setTextColor(R.id.note_text, textColor);

        } catch (Exception e) {
            views.setInt(R.id.note_layout, "setBackgroundColor", Color.BLACK);
            views.setTextColor(R.id.note_text, Color.WHITE);
        }

        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Note Widget Static Update: " + noteText);
    }

    // Метод для определения контрастного цвета текста
    private static int getContrastColor(int backgroundColor) {
        // Вычисляем яркость цвета по формуле
        double luminance = (0.299 * Color.red(backgroundColor) +
                0.587 * Color.green(backgroundColor) +
                0.114 * Color.blue(backgroundColor)) / 255;

        // Если фон светлый - черный текст, если темный - белый текст
        return luminance > 0.5 ? Color.BLACK : Color.WHITE;
    }
}