package com.example.smartsy;

import com.google.gson.annotations.SerializedName;

public class CurrencyData {
    @SerializedName("Valute")
    private Valute valute;

    public Valute getValute() { return valute; }

    public static class Valute {
        @SerializedName("USD")
        private Currency usd;

        @SerializedName("EUR")
        private Currency eur;

        public Currency getUSD() { return usd; }
        public Currency getEUR() { return eur; }
    }

    public static class Currency {
        @SerializedName("Value")
        private double value;

        @SerializedName("Name")
        private String name;

        public double getValue() { return value; }
        public String getName() { return name; }
    }
}