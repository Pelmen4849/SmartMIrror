package com.example.smartsy;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartsy.Widget.WidgetItem;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.Socket;

public class NoteCreationActivity extends AppCompatActivity {

    private EditText noteInput;
    private RadioGroup colorGroup;
    private LinearLayout previewLayout;
    private TextView previewText;
    private Button backBtn, addNoteBtn;

    private String selectedColor = "#000000"; // Черный по умолчанию
    private String noteText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_creation);

        initViews();
        setupListeners();
        updatePreview();
    }

    private void initViews() {
        noteInput = findViewById(R.id.noteInput);
        colorGroup = findViewById(R.id.colorGroup);
        previewLayout = findViewById(R.id.previewLayout);
        previewText = findViewById(R.id.previewText);
        backBtn = findViewById(R.id.backBtn);
        addNoteBtn = findViewById(R.id.addNoteBtn);
    }

    private void setupListeners() {
        // Слушатель изменения текста
        noteInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                noteText = s.toString();
                updatePreview();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Слушатель выбора цвета
        colorGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioRed) {
                selectedColor = "#FF0000"; // Красный
            } else if (checkedId == R.id.radioBlack) {
                selectedColor = "#000000"; // Черный
            } else if (checkedId == R.id.radioBlue) {
                selectedColor = "#006400"; // Насыщенный зеленый
            }
            updatePreview();
        });

        // Кнопка Назад
        backBtn.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        // Кнопка Добавить
        addNoteBtn.setOnClickListener(v -> {
            if (noteText.trim().isEmpty()) {
                Toast.makeText(this, "Введите текст заметки", Toast.LENGTH_SHORT).show();
                return;
            }

            // Создаем виджет заметки
            createNoteWidget();
        });
    }

    private void updatePreview() {
        previewText.setText(noteText.isEmpty() ? "Предпросмотр заметки" : noteText);
        previewLayout.setBackgroundColor(Color.parseColor(selectedColor));

        // Меняем цвет текста в зависимости от фона для лучшей читаемости
        if (selectedColor.equals("#000000")) { // Черный фон - белый текст
            previewText.setTextColor(Color.WHITE);
        } else { // Красный или зеленый фон - черный текст
            previewText.setTextColor(Color.BLACK);
        }
    }

    private void createNoteWidget() {
        // Проверяем, создается ли заметка для удаленного устройства
        boolean forRemoteDevice = getIntent().getBooleanExtra("for_remote_device", false);
        String remoteDeviceIp = getIntent().getStringExtra("remote_device_ip");

        // Создаем JSON с данными заметки
        String additionalInfo = String.format(
                "{\"text\":\"%s\",\"color\":\"%s\",\"type\":\"note\"}",
                noteText, selectedColor
        );

        // Создаем виджет
        WidgetItem noteItem = new WidgetItem(
                0,
                "note",
                "Заметка",
                noteText.length() > 20 ? noteText.substring(0, 20) + "..." : noteText,
                additionalInfo
        );

        // Сохраняем заметку в SharedPreferences для виджета
        saveNoteToPreferences(noteText, selectedColor);

        // Возвращаем результат в основную активность
        Intent resultIntent = new Intent();
        resultIntent.putExtra("note_item", noteItem);

        // Передаем информацию о том, для какого устройства создавалась заметка
        if (forRemoteDevice) {
            resultIntent.putExtra("for_remote_device", true);
            resultIntent.putExtra("remote_device_ip", remoteDeviceIp);

            // ОТПРАВЛЯЕМ ЗАМЕТКУ НА ЗЕРКАЛО СРАЗУ ЖЕ
            sendNoteToMirror(noteItem, remoteDeviceIp);
        }

        setResult(RESULT_OK, resultIntent);

        if (forRemoteDevice) {
            // Для удаленного устройства просто закрываем активность
            Toast.makeText(this, "Заметка создана для отправки на зеркало!", Toast.LENGTH_SHORT).show();
        } else {
            // Для локального устройства закрепляем виджет на домашнем экране
            pinNoteWidgetToHomeScreen();
            Toast.makeText(this, "Заметка создана и добавлена на домашний экран!", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    // НОВЫЙ МЕТОД: Отправка заметки непосредственно на зеркало
    private void sendNoteToMirror(WidgetItem noteItem, String remoteDeviceIp) {
        new Thread(() -> {
            try {
                // Создаем JSON для отправки
                JSONObject json = new JSONObject();
                json.put("type", "note");
                json.put("title", noteItem.getTitle());
                json.put("data", noteItem.getData());
                json.put("additionalInfo", noteItem.getAdditionalInfo());
                json.put("timestamp", System.currentTimeMillis());

                String payload = json.toString();
                Log.d("NoteCreation", "📨 Отправка заметки на зеркало: " + remoteDeviceIp);
                Log.d("NoteCreation", "📦 Данные: " + payload);

                // Отправляем данные на зеркало
                Socket socket = new Socket(remoteDeviceIp, 8080);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(payload.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();
                socket.close();

                Log.d("NoteCreation", "✅ Заметка успешно отправлена на зеркало");

                // Отправляем команду обновления виджетов
                sendWidgetUpdateCommand(remoteDeviceIp);

            } catch (Exception e) {
                Log.e("NoteCreation", "❌ Ошибка отправки заметки на зеркало", e);
                runOnUiThread(() -> {
                    Toast.makeText(NoteCreationActivity.this, "Ошибка отправки на зеркало: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    // НОВЫЙ МЕТОД: Отправка команды обновления виджетов
    private void sendWidgetUpdateCommand(String remoteDeviceIp) {
        new Thread(() -> {
            try {
                // Ждем немного перед отправкой команды обновления
                Thread.sleep(500);

                JSONObject updateCommand = new JSONObject();
                updateCommand.put("type", "command");
                updateCommand.put("action", "update_widgets");
                updateCommand.put("timestamp", System.currentTimeMillis());

                String commandPayload = updateCommand.toString();

                Socket socket = new Socket(remoteDeviceIp, 8080);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(commandPayload.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();
                socket.close();

                Log.d("NoteCreation", "✅ Команда обновления отправлена на зеркало");
            } catch (Exception e) {
                Log.e("NoteCreation", "❌ Ошибка отправки команды обновления", e);
            }
        }).start();
    }

    private void saveNoteToPreferences(String noteText, String color) {
        SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("note_text", noteText);
        editor.putString("note_background", color);
        editor.putLong("last_note_update", System.currentTimeMillis());
        editor.apply();

        Log.d("Note", "Заметка сохранена в SharedPreferences: " + noteText.substring(0, Math.min(20, noteText.length())));
    }

    private void pinNoteWidgetToHomeScreen() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            showManualNoteWidgetInstructions();
            return;
        }

        AppWidgetManager appWidgetManager = getSystemService(AppWidgetManager.class);
        ComponentName widgetComponent = new ComponentName(this, NoteWidget.class);

        if (appWidgetManager.isRequestPinAppWidgetSupported()) {
            requestPinNoteWidget(appWidgetManager, widgetComponent);
        } else {
            showManualNoteWidgetInstructions();
        }
    }

    private void requestPinNoteWidget(AppWidgetManager appWidgetManager, ComponentName widgetComponent) {
        Intent pinnedWidgetCallbackIntent = new Intent(this, NoteCreationActivity.class);
        pinnedWidgetCallbackIntent.setAction("APPWIDGET_PINNED_NOTE");

        PendingIntent successCallback = PendingIntent.getActivity(
                this,
                0,
                pinnedWidgetCallbackIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        try {
            boolean success = false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                success = appWidgetManager.requestPinAppWidget(widgetComponent, null, successCallback);
            }

            if (success) {
                Toast.makeText(this, "Разрешите добавление виджета заметки в появившемся окне", Toast.LENGTH_SHORT).show();
            } else {
                showManualNoteWidgetInstructions();
            }
        } catch (Exception e) {
            Log.e("NoteWidget", "Ошибка при закреплении виджета заметки", e);
            showManualNoteWidgetInstructions();
        }
    }

    private void showManualNoteWidgetInstructions() {
        String message = "Виджет заметки готов к добавлению!\n\n" +
                "Чтобы добавить виджет:\n" +
                "1. Перейдите на главный экран\n" +
                "2. Сделайте долгое нажатие\n" +
                "3. Выберите \"Виджеты\"\n" +
                "4. Найдите \"Smartsy - Заметка\" и перетащите виджет на экран";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        // Обновляем виджеты
        updateNoteWidgets();
    }

    private void updateNoteWidgets() {
        Intent intent = new Intent(this, NoteWidget.class);
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(this)
                .getAppWidgetIds(new ComponentName(this, NoteWidget.class));
        if (ids.length > 0) {
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            sendBroadcast(intent);
            Log.d("NoteWidget", "Обновление виджетов заметок: " + ids.length + " шт.");
        }
    }
}