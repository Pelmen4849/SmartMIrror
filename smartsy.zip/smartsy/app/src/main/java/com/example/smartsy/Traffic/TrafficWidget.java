package com.example.smartsy.Traffic;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import com.example.smartsy.R;

public class TrafficWidget extends AppWidgetProvider {

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);
        String city = prefs.getString("traffic_city", "Город");
        int level = prefs.getInt("traffic_level", 0);
        String levelName = prefs.getString("traffic_level_name", "Неизвестно");
        String hint = prefs.getString("traffic_hint", "Данные загружаются");

        // Получаем цвет в зависимости от уровня пробок
        int color = getTrafficColor(level);
        String emoji = getTrafficEmoji(level);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_traffic);
        views.setTextViewText(R.id.traffic_city, city);
        views.setTextViewText(R.id.traffic_level, emoji + " " + levelName);
        views.setTextViewText(R.id.traffic_hint, hint);
        views.setTextColor(R.id.traffic_level, color);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // При первом создании виджета
    }

    @Override
    public void onDisabled(Context context) {
        // Когда последний виджет удален
    }

    private static int getTrafficColor(int level) {
        switch (level) {
            case 1: return 0xFF4CAF50; // Зеленый
            case 2: return 0xFFFFC107; // Желтый
            case 3: return 0xFFFF9800; // Оранжевый
            case 4: return 0xFFF44336; // Красный
            case 5: return 0xFF9C27B0; // Фиолетовый (пробки)
            default: return 0xFF607D8B; // Серый
        }
    }

    private static String getTrafficEmoji(int level) {
        switch (level) {
            case 1: return "🟢"; // Свободно
            case 2: return "🟡"; // Местами затруднения
            case 3: return "🟠"; // Затруднения
            case 4: return "🔴"; // Серьезные затруднения
            case 5: return "🟣"; // Пробки
            default: return "⚫"; // Неизвестно
        }
    }
}