package com.example.smartsy;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsy.Currency.CurrencyApi;
import com.example.smartsy.Currency.CurrencyData;
import com.example.smartsy.Currency.CurrencyWidget;
import com.example.smartsy.Weather.WeatherApi;
import com.example.smartsy.Weather.WeatherData;
import com.example.smartsy.Weather.WeatherWidget;
import com.example.smartsy.Widget.WidgetEntity;
import com.example.smartsy.Widget.WidgetItem;
import com.example.smartsy.Widget.WidgetsAdapter;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class add_vidgets extends AppCompatActivity implements WidgetsAdapter.OnWidgetDeleteListener {

    private EditText cityInput;
    private Spinner currencySpinner;
    private Button addWeatherBtn, addCurrencyBtn, saveWidgetsBtn, autoDetectBtn, refreshCurrencyBtn;
    private Button scanQrBtn, sendWidgetsBtn, testSendCurrencyBtn, testSendWeatherBtn, createNoteBtn;
    private ProgressBar weatherProgress, currencyProgress;
    private TextView weatherError, currencyError, connectionStatus;
    private RecyclerView widgetsRecyclerView;
    private RadioGroup weatherMethodGroup;
    private RadioButton radioAuto, radioManual;
    private LinearLayout manualInputLayout;

    private List<WidgetItem> widgetItems = new ArrayList<>();
    private WidgetsAdapter adapter;
    private AppDatabase database;
    private Executor executor = Executors.newSingleThreadExecutor();

    private WeatherApi weatherApi;
    private CurrencyApi currencyApi;
    private FusedLocationProviderClient fusedLocationClient;
    private NetworkManager networkManager;

    private List<CurrencyData.Currency> availableCurrencies = new ArrayList<>();
    private ArrayAdapter<String> currencyAdapter;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private static final int PIN_WIDGET_REQUEST_CODE = 1002;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1003;
    private static final int CREATE_NOTE_REQUEST_CODE = 1004;

    private String connectedDeviceIp = null;
    private boolean isConnected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_vidgets);

        database = ((SmartsyApp) getApplication()).getDatabase();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        networkManager = new NetworkManager();

        initViews();
        setupRecyclerView();
        setupRetrofit();
        setupCurrencySpinner();
        setupListeners();
        loadSavedWidgets();
        loadAvailableCurrencies();
        handlePinWidgetCallback();

        // Тестируем API при запуске
        testWeatherAPI();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initViews() {
        cityInput = findViewById(R.id.cityInput);
        currencySpinner = findViewById(R.id.currencySpinner);
        addWeatherBtn = findViewById(R.id.addWeatherBtn);
        addCurrencyBtn = findViewById(R.id.addCurrencyBtn);
        saveWidgetsBtn = findViewById(R.id.saveWidgetsBtn);
        autoDetectBtn = findViewById(R.id.autoDetectBtn);
        refreshCurrencyBtn = findViewById(R.id.refreshCurrencyBtn);
        scanQrBtn = findViewById(R.id.scanQrBtn);
        sendWidgetsBtn = findViewById(R.id.sendWidgetsBtn);
        testSendCurrencyBtn = findViewById(R.id.testSendCurrencyBtn);
        testSendWeatherBtn = findViewById(R.id.testSendWeatherBtn);
        createNoteBtn = findViewById(R.id.createNoteBtn);
        weatherProgress = findViewById(R.id.weatherProgress);
        currencyProgress = findViewById(R.id.currencyProgress);
        weatherError = findViewById(R.id.weatherError);
        currencyError = findViewById(R.id.currencyError);
        connectionStatus = findViewById(R.id.connectionStatus);
        widgetsRecyclerView = findViewById(R.id.widgetsRecyclerView);

        weatherMethodGroup = findViewById(R.id.weatherMethodGroup);
        radioAuto = findViewById(R.id.radioAuto);
        radioManual = findViewById(R.id.radioManual);
        manualInputLayout = findViewById(R.id.manualInputLayout);

        updateConnectionUI();
    }

    private void setupListeners() {
        scanQrBtn.setOnClickListener(v -> {
            Log.d("QRScan", "Нажата кнопка сканирования QR-кода");
            scanQRCode();
        });

        sendWidgetsBtn.setOnClickListener(v -> {
            if (connectedDeviceIp == null || !isConnected) {
                Toast.makeText(add_vidgets.this, "Сначала подключитесь к устройству через QR-код", Toast.LENGTH_SHORT).show();
                return;
            }
            if (widgetItems.isEmpty()) {
                Toast.makeText(add_vidgets.this, "Нет виджетов для отправки", Toast.LENGTH_SHORT).show();
                return;
            }
            sendWidgetsToDevice();
        });

        // ТЕСТОВЫЕ КНОПКИ
        testSendCurrencyBtn.setOnClickListener(v -> {
            if (!isConnected) {
                Toast.makeText(add_vidgets.this, "Сначала подключитесь к устройству", Toast.LENGTH_SHORT).show();
                return;
            }
            sendTestCurrency();
        });

        testSendWeatherBtn.setOnClickListener(v -> {
            if (!isConnected) {
                Toast.makeText(add_vidgets.this, "Сначала подключитесь к устройству", Toast.LENGTH_SHORT).show();
                return;
            }
            sendTestWeather();
        });

        // КНОПКА СОЗДАНИЯ ЗАМЕТКИ
        createNoteBtn.setOnClickListener(v -> {
            showAddWidgetDialog("note", this::createNote);
        });

        weatherMethodGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioAuto) {
                manualInputLayout.setVisibility(View.GONE);
                autoDetectBtn.setVisibility(View.VISIBLE);
            } else {
                manualInputLayout.setVisibility(View.VISIBLE);
                autoDetectBtn.setVisibility(View.GONE);
            }
        });

        addWeatherBtn.setOnClickListener(v -> {
            String city = cityInput.getText().toString().trim();
            if (city.isEmpty()) {
                weatherError.setText("Введите город");
                weatherError.setVisibility(View.VISIBLE);
            } else {
                showAddWidgetDialog("weather", () -> fetchWeatherByCity(city));
            }
        });

        autoDetectBtn.setOnClickListener(v -> {
            showAddWidgetDialog("weather", this::getCurrentLocation);
        });

        addCurrencyBtn.setOnClickListener(v -> {
            int selectedPosition = currencySpinner.getSelectedItemPosition();
            if (selectedPosition >= 0 && selectedPosition < availableCurrencies.size()) {
                CurrencyData.Currency selectedCurrency = availableCurrencies.get(selectedPosition);
                showAddWidgetDialog("currency", () -> addCurrencyWidget(selectedCurrency));
            } else {
                currencyError.setText("Выберите валюту из списка");
                currencyError.setVisibility(View.VISIBLE);
            }
        });

        refreshCurrencyBtn.setOnClickListener(v -> {
            loadAvailableCurrencies();
        });

        saveWidgetsBtn.setOnClickListener(v -> finish());
    }

    // ==================== ИСПРАВЛЕННЫЙ МЕТОД ДИАЛОГА ====================
    private void showAddWidgetDialog(String widgetType, Runnable addAction) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Добавить виджет");

        if (isConnected && connectedDeviceIp != null) {
            // Если есть подключение к удаленному устройству, предлагаем оба варианта
            builder.setMessage("Куда добавить виджет?\n\nПодключено к: " + connectedDeviceIp);

            builder.setPositiveButton("На это устройство", (dialog, which) -> {
                Log.d("WidgetDialog", "✅ Добавление на ЭТО устройство");
                addAction.run();
            });

            builder.setNeutralButton("На зеркало (" + connectedDeviceIp + ")", (dialog, which) -> {
                Log.d("WidgetDialog", "📡 Добавление на УДАЛЕННОЕ устройство: " + connectedDeviceIp);
                addWidgetToRemoteDevice(widgetType);
            });

            builder.setNegativeButton("Отмена", null);

        } else {
            // Если нет подключения, предлагаем только локальное добавление
            builder.setMessage("Добавить виджет на это устройство?");

            builder.setPositiveButton("Добавить", (dialog, which) -> {
                Log.d("WidgetDialog", "✅ Добавление на ЭТО устройство");
                addAction.run();
            });

            builder.setNegativeButton("Отмена", null);
        }

        builder.show();
    }

    // ==================== ИСПРАВЛЕННЫЙ МЕТОД ДЛЯ УДАЛЕННОГО УСТРОЙСТВА ====================
    private void addWidgetToRemoteDevice(String widgetType) {
        Log.d("RemoteWidget", "🎯 === ДОБАВЛЕНИЕ ВИДЖЕТА НА УДАЛЕННОЕ УСТРОЙСТВО ===");

        if (!isConnected || connectedDeviceIp == null) {
            Log.e("RemoteWidget", "❌ НЕТ ПОДКЛЮЧЕНИЯ К УСТРОЙСТВУ");
            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "❌ Сначала подключитесь к устройству через QR-код", Toast.LENGTH_SHORT).show();
            });
            return;
        }

        switch (widgetType) {
            case "weather":
                String city = cityInput.getText().toString().trim();
                if (city.isEmpty()) {
                    Toast.makeText(add_vidgets.this, "Введите город для отправки виджета погоды", Toast.LENGTH_SHORT).show();
                    return;
                }
                Log.d("RemoteWidget", "🌤️ Отправка погоды на удаленное устройство: " + city);
                fetchAndSendRealWeather(city);
                break;
            case "currency":
                WidgetItem remoteItem = createCurrencyWidgetWithRealData();
                if (remoteItem != null) {
                    sendCurrencyWidgetToDevice(remoteItem);
                }
                break;
            case "note":
                // ДЛЯ ЗАМЕТОК: открываем создание заметки для удаленного устройства
                // Отправка произойдет автоматически в NoteCreationActivity
                Log.d("RemoteWidget", "📝 Создание заметки для отправки на удаленное устройство");
                createNoteForRemoteDevice();
                break;
        }
    }

    // НОВЫЙ МЕТОД: Создание заметки специально для удаленного устройства
    private void createNoteForRemoteDevice() {
        Intent intent = new Intent(add_vidgets.this, NoteCreationActivity.class);
        // Передаем флаг, что это для удаленного устройства
        intent.putExtra("for_remote_device", true);
        intent.putExtra("remote_device_ip", connectedDeviceIp);
        startActivityForResult(intent, CREATE_NOTE_REQUEST_CODE);
    }

    // ==================== МЕТОДЫ ДЛЯ ЗАМЕТОК ====================
    private void createNote() {
        Intent intent = new Intent(add_vidgets.this, NoteCreationActivity.class);
        startActivityForResult(intent, CREATE_NOTE_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("ActivityResult", "onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);

        // Обработка результата создания заметки
        if (requestCode == CREATE_NOTE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            WidgetItem noteItem = data.getParcelableExtra("note_item");
            if (noteItem != null) {
                // Проверяем, была ли заметка создана для удаленного устройства
                boolean forRemoteDevice = data.getBooleanExtra("for_remote_device", false);
                String remoteIp = data.getStringExtra("remote_device_ip");

                if (forRemoteDevice && remoteIp != null && isConnected && remoteIp.equals(connectedDeviceIp)) {
                    // ДЛЯ УДАЛЕННОГО УСТРОЙСТВА: заметка уже отправлена из NoteCreationActivity
                    // Просто добавляем в историю и показываем уведомление
                    Log.d("RemoteNote", "✅ Заметка уже отправлена на зеркало из NoteCreationActivity");

                    widgetItems.add(noteItem);
                    adapter.updateData(widgetItems);
                    saveWidget(noteItem);
                    saveWidgetToSharedPrefs(noteItem);

                    Toast.makeText(this, "✅ Заметка отправлена на зеркало!", Toast.LENGTH_SHORT).show();
                } else {
                    // ДЛЯ ЛОКАЛЬНОГО УСТРОЙСТВА: добавляем локально
                    widgetItems.add(noteItem);
                    adapter.updateData(widgetItems);
                    saveWidget(noteItem);
                    saveWidgetToSharedPrefs(noteItem);

                    // ОБНОВЛЯЕМ ВИДЖЕТЫ ЗАМЕТОК
                    updateNoteWidgets();

                    Toast.makeText(this, "Заметка добавлена на это устройство!", Toast.LENGTH_SHORT).show();
                }
            }
        }

        // Обработка QR-сканирования
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() != null) {
                String qrContent = result.getContents().trim();
                Log.d("QRScan", "Успешно сканировано: " + qrContent);
                processScannedQRCode(qrContent);
            } else {
                Log.d("QRScan", "Сканирование отменено пользователем");
                Toast.makeText(add_vidgets.this, "Сканирование отменено", Toast.LENGTH_SHORT).show();
            }
        }

        handlePinWidgetCallback();
    }

    // ==================== ТЕСТИРОВАНИЕ API ====================
    private void testWeatherAPI() {
        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";
        String testCity = "Moscow";

        Log.d("APITest", "🔧 Тестирование API погоды...");

        Call<WeatherData> call = weatherApi.getCurrentWeather(testCity, "metric", "ru", apiKey);
        call.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData data = response.body();
                    Log.d("APITest", "✅ API работает: " + data.getCityName() + " " + data.getMain().getTemp() + "°C");
                } else {
                    Log.e("APITest", "❌ API ошибка: " + response.code() + " - " + response.message());
                    if (response.code() == 401) {
                        Log.e("APITest", "❌ Неверный API ключ!");
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                Log.e("APITest", "❌ API сеть: " + t.getMessage());
            }
        });
    }

    // ==================== ТЕСТОВЫЕ МЕТОДЫ ОТПРАВКИ ====================
    private void sendTestCurrency() {
        new Thread(() -> {
            try {
                String data = "{\"type\":\"currency\",\"title\":\"USD/RUB\",\"data\":\"90.45\",\"additionalInfo\":\"+0.5%\"}";

                Log.d("TestSend", "📨 Отправка тестовой валюты: " + data);

                Socket socket = new Socket(connectedDeviceIp, 8080);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(data.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();
                socket.close();

                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "✅ Тестовая валюта отправлена!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                Log.e("TestSend", "❌ Ошибка отправки теста валюты", e);
                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "❌ Ошибка отправки: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void sendTestWeather() {
        if (!isConnected) {
            Toast.makeText(add_vidgets.this, "Сначала подключитесь к устройству", Toast.LENGTH_SHORT).show();
            return;
        }

        // Создаем final переменные
        final String testCity;
        String inputCity = cityInput.getText().toString().trim();
        if (inputCity.isEmpty()) {
            testCity = "Москва";
        } else {
            testCity = inputCity;
        }

        final int testTemp = (int) (Math.random() * 40) - 10;
        String[] descriptions = {"Ясно", "Облачно", "Небольшой дождь", "Пасмурно", "Снег"};
        final String testDescription = descriptions[(int) (Math.random() * descriptions.length)];

        new Thread(() -> {
            try {
                String data = String.format("{\"type\":\"weather\",\"title\":\"Погода в %s\",\"data\":\"%d°C\",\"additionalInfo\":\"%s\"}",
                        testCity, testTemp, testDescription);

                Log.d("TestSend", "📨 Отправка тестовой погоды: " + data);

                Socket socket = new Socket(connectedDeviceIp, 8080);
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(data.getBytes("UTF-8"));
                outputStream.flush();
                outputStream.close();
                socket.close();

                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "✅ Тестовая погода отправлена для " + testCity + "!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                Log.e("TestSend", "❌ Ошибка отправки теста погоды", e);
                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "❌ Ошибка отправки: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С РЕАЛЬНЫМИ ДАННЫМИ ПОГОДЫ ====================
    private void fetchAndSendRealWeather(String city) {
        showWeatherLoading(true);
        weatherError.setVisibility(View.GONE);

        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";

        Log.d("Weather", "🌤️ === НАЧАЛО ЗАПРОСА ПОГОДЫ ===");
        Log.d("Weather", "📍 Город: " + city);
        Log.d("Weather", "🔑 API ключ: " + apiKey.substring(0, 8) + "...");

        // Запрос текущей погоды
        Call<WeatherData> currentCall = weatherApi.getCurrentWeather(city, "metric", "ru", apiKey);
        currentCall.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                Log.d("Weather", "📡 ОТВЕТ ОТ API ПОГОДЫ");
                Log.d("Weather", "🔢 Код ответа: " + response.code());
                Log.d("Weather", "📝 Сообщение: " + response.message());

                if (response.isSuccessful() && response.body() != null) {
                    WeatherData currentData = response.body();
                    Log.d("Weather", "✅ ТЕКУЩАЯ ПОГОДА ПОЛУЧЕНА");
                    Log.d("Weather", "🏙️ Город: " + currentData.getCityName());
                    Log.d("Weather", "🌡️ Температура: " + currentData.getMain().getTemp());
                    Log.d("Weather", "📝 Описание: " + currentData.getWeather()[0].getDescription());

                    // Теперь запрашиваем прогноз
                    fetchWeatherForecast(city, currentData);
                } else {
                    showWeatherLoading(false);
                    String errorBody = "";
                    try {
                        if (response.errorBody() != null) {
                            errorBody = response.errorBody().string();
                            Log.e("Weather", "❌ ТЕЛО ОШИБКИ: " + errorBody);
                        }
                    } catch (Exception e) {
                        Log.e("Weather", "❌ ОШИБКА ЧТЕНИЯ ТЕЛА ОШИБКИ", e);
                    }

                    Log.e("Weather", "❌ ОШИБКА ПОЛУЧЕНИЯ ТЕКУЩЕЙ ПОГОДЫ");
                    Log.e("Weather", "🔢 Код ошибки: " + response.code());
                    Log.e("Weather", "📝 Сообщение: " + response.message());

                    weatherError.setText("Ошибка получения погоды: " + response.code() + " - " + response.message());
                    weatherError.setVisibility(View.VISIBLE);
                    handleWeatherError(response);
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                showWeatherLoading(false);
                Log.e("Weather", "❌ СЕТЕВАЯ ОШИБКА ПОЛУЧЕНИЯ ПОГОДЫ");
                Log.e("Weather", "📡 Сообщение: " + t.getMessage());
                Log.e("Weather", "🔍 Stacktrace:", t);

                weatherError.setText("Ошибка сети: " + t.getMessage());
                weatherError.setVisibility(View.VISIBLE);
            }
        });
    }

    private void fetchWeatherForecast(String city, WeatherData currentData) {
        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";

        Log.d("Weather", "🌤️ === ЗАПРОС ПРОГНОЗА ПОГОДЫ ===");
        Log.d("Weather", "📍 Город для прогноза: " + city);

        // Запрос прогноза на 5 дней с интервалом 3 часа
        Call<WeatherData.ForecastResponse> forecastCall = weatherApi.getWeatherForecast(city, "metric", "ru", apiKey);
        forecastCall.enqueue(new Callback<WeatherData.ForecastResponse>() {
            @Override
            public void onResponse(Call<WeatherData.ForecastResponse> call, Response<WeatherData.ForecastResponse> response) {
                Log.d("Weather", "📡 ОТВЕТ ОТ API ПРОГНОЗА");
                Log.d("Weather", "🔢 Код ответа: " + response.code());
                Log.d("Weather", "📝 Сообщение: " + response.message());

                showWeatherLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData.ForecastResponse forecastResponse = response.body();
                    List<WeatherData.ForecastItem> forecastItems = forecastResponse.getList();

                    if (forecastItems != null && !forecastItems.isEmpty()) {
                        Log.d("Weather", "✅ ПРОГНОЗ ПОЛУЧЕН");
                        Log.d("Weather", "📊 Количество записей прогноза: " + forecastItems.size());

                        // Берем первые 3 прогноза (ближайшие 3, 6, 9 часов)
                        List<WeatherData.ForecastItem> nextForecasts = forecastItems.subList(0, Math.min(3, forecastItems.size()));

                        Log.d("Weather", "📈 Используем прогнозы: " + nextForecasts.size() + " записей");

                        // Обрабатываем текущую погоду с прогнозом
                        processWeatherData(currentData, nextForecasts);
                    } else {
                        Log.e("Weather", "❌ ПУСТОЙ ПРОГНОЗ");
                        processWeatherData(currentData, null);
                    }
                } else {
                    Log.e("Weather", "❌ ОШИБКА ПОЛУЧЕНИЯ ПРОГНОЗА");
                    Log.e("Weather", "🔢 Код ошибки: " + response.code());

                    String errorBody = "";
                    try {
                        if (response.errorBody() != null) {
                            errorBody = response.errorBody().string();
                            Log.e("Weather", "❌ ТЕЛО ОШИБКИ ПРОГНОЗА: " + errorBody);
                        }
                    } catch (Exception e) {
                        Log.e("Weather", "❌ ОШИБКА ЧТЕНИЯ ТЕЛА ОШИБКИ ПРОГНОЗА", e);
                    }

                    // Если прогноз не получен, отправляем только текущую погоду
                    processWeatherData(currentData, null);
                }
            }

            @Override
            public void onFailure(Call<WeatherData.ForecastResponse> call, Throwable t) {
                showWeatherLoading(false);
                Log.e("Weather", "❌ СЕТЕВАЯ ОШИБКА ПОЛУЧЕНИЯ ПРОГНОЗА");
                Log.e("Weather", "📡 Сообщение: " + t.getMessage());
                Log.e("Weather", "🔍 Stacktrace:", t);

                // Если прогноз не получен, отправляем только текущую погоду
                processWeatherData(currentData, null);
            }
        });
    }

    private void processWeatherData(WeatherData currentData, List<WeatherData.ForecastItem> forecastItems) {
        Log.d("Weather", "🔄 === ОБРАБОТКА ДАННЫХ ПОГОДЫ ===");

        int temp = (int) Math.round(currentData.getMain().getTemp());
        String description = currentData.getWeather()[0].getDescription();
        String actualCity = currentData.getCityName();
        String icon = currentData.getWeather()[0].getIcon();

        double windSpeed = currentData.getWind() != null ? currentData.getWind().getSpeed() : 0;
        String windSpeedText = String.format(Locale.getDefault(), "%.1f м/с", windSpeed);

        Log.d("Weather", "✅ ДАННЫЕ ДЛЯ ОТПРАВКИ:");
        Log.d("Weather", "🏙️ Город: " + actualCity);

        // Сохраняем данные в SharedPreferences для виджета
        saveWeatherToPreferences(currentData, forecastItems);

        // Создаем виджет с РЕАЛЬНЫМИ данными
        WidgetItem remoteItem = createWeatherWidgetItem(currentData, forecastItems);

        if (remoteItem != null) {
            Log.d("Weather", "✅ ВИДЖЕТ СОЗДАН: " + remoteItem.getTitle());

            // Сохраняем локально для истории
            saveWidget(remoteItem);
            saveWidgetToSharedPrefs(remoteItem);

            // ОТПРАВЛЯЕМ ТОЛЬКО ЕСЛИ ПОДКЛЮЧЕНЫ К УДАЛЕННОМУ УСТРОЙСТВУ
            if (isConnected && connectedDeviceIp != null) {
                Log.d("Weather", "📡 Отправка на удаленное устройство: " + connectedDeviceIp);
                sendWeatherWidgetToDevice(remoteItem);
            } else {
                Log.d("Weather", "📱 Добавление локального виджета на это устройство");
                runOnUiThread(() -> {
                    // Добавляем в локальный список
                    widgetItems.add(remoteItem);
                    adapter.updateData(widgetItems);

                    // Создаем локальный виджет
                    addWeatherWidgetToHomeScreen(actualCity, temp + "°C", description);
                    Toast.makeText(add_vidgets.this, "✅ Погода добавлена на это устройство: " + actualCity, Toast.LENGTH_SHORT).show();
                });
            }
        } else {
            Log.e("Weather", "❌ НЕ УДАЛОСЬ СОЗДАТЬ ВИДЖЕТ");
            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "Ошибка создания виджета погоды", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void saveWeatherToPreferences(WeatherData currentData, List<WeatherData.ForecastItem> forecastItems) {
        SharedPreferences prefs = getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // Сохраняем текущие данные
        editor.putString("weather_city", currentData.getCityName());
        editor.putString("weather_temp", String.format(Locale.getDefault(), "%d°C", (int) Math.round(currentData.getMain().getTemp())));
        editor.putString("weather_description", currentData.getWeather()[0].getDescription());
        editor.putString("weather_icon", currentData.getWeather()[0].getIcon());

        // Сохраняем скорость ветра
        if (currentData.getWind() != null) {
            editor.putString("weather_wind", String.format(Locale.getDefault(), "%.1f м/с", currentData.getWind().getSpeed()));
        } else {
            editor.putString("weather_wind", "0 м/с");
        }

        editor.putLong("last_weather_update", System.currentTimeMillis());

        // Сохраняем прогноз (первые 3 пункта)
        if (forecastItems != null && forecastItems.size() >= 3) {
            for (int i = 0; i < 3; i++) {
                WeatherData.ForecastItem item = forecastItems.get(i);

                // Форматируем время (только часы)
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
                String time = sdf.format(new Date(item.getTimestamp() * 1000));

                // Температура
                String temp = String.format(Locale.getDefault(), "%.0f°", item.getMain().getTemp());

                // Иконка
                String icon = item.getWeather().get(0).getIcon();

                editor.putString("forecast_" + (i + 1) + "_time", time);
                editor.putString("forecast_" + (i + 1) + "_temp", temp);
                editor.putString("forecast_" + (i + 1) + "_icon", icon);
            }
        } else {
            // Если прогноза нет, очищаем старые данные
            for (int i = 1; i <= 3; i++) {
                editor.remove("forecast_" + i + "_time");
                editor.remove("forecast_" + i + "_temp");
                editor.remove("forecast_" + i + "_icon");
            }
        }

        editor.apply();
        Log.d("Weather", "✅ Данные погоды сохранены в SharedPreferences");
    }

    // ИСПРАВЛЕННЫЙ МЕТОД СОЗДАНИЯ ВИДЖЕТА ПОГОДЫ
    private WidgetItem createWeatherWidgetItem(WeatherData currentData, List<WeatherData.ForecastItem> forecastItems) {
        Log.d("Weather", "🔧 === СОЗДАНИЕ ВИДЖЕТА ПОГОДЫ ===");

        String city = currentData.getCityName();
        int temp = (int) Math.round(currentData.getMain().getTemp());
        String description = currentData.getWeather()[0].getDescription();
        String icon = currentData.getWeather()[0].getIcon();

        // Формируем дополнительные данные для отправки
        JSONObject additionalInfo = new JSONObject();
        try {
            Log.d("Weather", "📦 Формирование JSON дополнительной информации");

            // ОСНОВНЫЕ ДАННЫЕ - исправляем структуру
            additionalInfo.put("icon", icon);
            additionalInfo.put("wind_speed", currentData.getWind() != null ? currentData.getWind().getSpeed() : 0);
            additionalInfo.put("humidity", currentData.getMain().getHumidity());
            additionalInfo.put("pressure", currentData.getMain().getPressure());
            additionalInfo.put("description", description);

            Log.d("Weather", "📊 Основные данные добавлены в JSON");

            // Добавляем прогноз - исправляем структуру массива
            if (forecastItems != null && !forecastItems.isEmpty()) {
                Log.d("Weather", "📈 Добавление прогноза в JSON");

                JSONArray forecastArray = new JSONArray();
                int forecastCount = Math.min(3, forecastItems.size());

                for (int i = 0; i < forecastCount; i++) {
                    WeatherData.ForecastItem item = forecastItems.get(i);
                    JSONObject forecastItem = new JSONObject();

                    // Форматируем время
                    String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(item.getTimestamp() * 1000));
                    int forecastTemp = Math.toIntExact(Math.round(item.getMain().getTemp()));
                    String forecastIcon = item.getWeather().get(0).getIcon();

                    // ДОБАВЛЯЕМ КОРРЕКТНЫЕ КЛЮЧИ
                    forecastItem.put("time", time);
                    forecastItem.put("temp", forecastTemp);
                    forecastItem.put("icon", forecastIcon);

                    forecastArray.put(forecastItem);

                    Log.d("Weather", "⏰ Прогноз " + (i+1) + ": " + time + " - " + forecastTemp + "°C - " + forecastIcon);
                }
                additionalInfo.put("forecast", forecastArray);
                Log.d("Weather", "✅ Прогноз добавлен в JSON: " + forecastArray.length() + " элементов");
            } else {
                Log.d("Weather", "⚠️ Прогноз не добавлен (null или недостаточно данных)");
                // Добавляем пустой массив вместо null
                additionalInfo.put("forecast", new JSONArray());
            }

            Log.d("Weather", "✅ JSON дополнительной информации сформирован: " + additionalInfo.toString());

        } catch (JSONException e) {
            Log.e("Weather", "❌ ОШИБКА СОЗДАНИЯ JSON ДЛЯ ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ", e);
            // Создаем минимальный JSON в случае ошибки
            try {
                additionalInfo = new JSONObject();
                additionalInfo.put("icon", icon);
                additionalInfo.put("description", description);
                additionalInfo.put("forecast", new JSONArray());
            } catch (JSONException ex) {
                Log.e("Weather", "❌ КРИТИЧЕСКАЯ ОШИБКА СОЗДАНИЯ JSON", ex);
            }
        }

        // Создаем виджет
        WidgetItem widget = new WidgetItem(0, "weather", "Погода в " + city,
                temp + "°C", additionalInfo.toString());

        Log.d("Weather", "🎯 ВИДЖЕТ СОЗДАН:");
        Log.d("Weather", "📝 Заголовок: " + widget.getTitle());
        Log.d("Weather", "📊 Данные: " + widget.getData());
        Log.d("Weather", "ℹ️ Доп. информация: " + widget.getAdditionalInfo());

        return widget;
    }

    // МЕТОД ДЛЯ ПРОВЕРКИ ВАЛИДНОСТИ JSON
    private boolean isValidJSON(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return false;
        }
        try {
            new JSONObject(jsonString);
            return true;
        } catch (JSONException e) {
            Log.e("JSON", "❌ Невалидный JSON: " + jsonString, e);
            return false;
        }
    }

    // ИСПРАВЛЕННЫЙ МЕТОД ОТПРАВКИ ПОГОДЫ
    private void sendWeatherWidgetToDevice(WidgetItem weatherItem) {
        Log.d("SendRemote", "🚀 === НАЧАЛО ОТПРАВКИ ПОГОДЫ НА УСТРОЙСТВО ===");

        if (weatherItem == null) {
            Log.e("SendRemote", "❌ ОШИБКА: weatherItem is null");
            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "Ошибка: данные погоды не получены", Toast.LENGTH_SHORT).show();
            });
            return;
        }

        if (!isConnected) {
            Log.e("SendRemote", "❌ ОШИБКА: Нет подключения к устройству");
            Log.d("SendRemote", "🔌 isConnected: " + isConnected);
            Log.d("SendRemote", "🌐 connectedDeviceIp: " + connectedDeviceIp);

            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "Ошибка: данные погоды не получены", Toast.LENGTH_SHORT).show();
            });
            return;
        }

        Log.d("SendRemote", "✅ Параметры проверены:");
        Log.d("SendRemote", "📝 Заголовок: " + weatherItem.getTitle());
        Log.d("SendRemote", "📊 Данные: " + weatherItem.getData());
        Log.d("SendRemote", "🔗 IP устройства: " + connectedDeviceIp);
        Log.d("SendRemote", "📡 Порт: 8080");

        // СОЗДАЕМ ФИНАЛЬНЫЕ ПЕРЕМЕННЫЕ ДЛЯ ИСПОЛЬЗОВАНИЯ В ЛЯМБДА-ВЫРАЖЕНИИ
        final WidgetItem finalWeatherItem;
        try {
            // ПРОВЕРЯЕМ ВАЛИДНОСТЬ JSON
            if (!isValidJSON(weatherItem.getAdditionalInfo())) {
                Log.e("SendRemote", "❌ НЕВАЛИДНЫЙ JSON В ДОПОЛНИТЕЛЬНОЙ ИНФОРМАЦИИ");
                // Создаем минимальный валидный JSON
                JSONObject fallbackJson = new JSONObject();
                fallbackJson.put("icon", "01d");
                fallbackJson.put("description", "Данные недоступны");
                fallbackJson.put("forecast", new JSONArray());
                finalWeatherItem = new WidgetItem(weatherItem.getId(), weatherItem.getType(),
                        weatherItem.getTitle(), weatherItem.getData(), fallbackJson.toString());
            } else {
                finalWeatherItem = weatherItem;
            }

            JSONObject json = new JSONObject();
            json.put("type", finalWeatherItem.getType());
            json.put("title", finalWeatherItem.getTitle());
            json.put("data", finalWeatherItem.getData());
            json.put("additionalInfo", finalWeatherItem.getAdditionalInfo());
            json.put("timestamp", System.currentTimeMillis());

            String payload = json.toString();
            Log.d("SendRemote", "📦 ВАЛИДНЫЙ JSON сформирован:");
            Log.d("SendRemote", "🔤 Длина JSON: " + payload.length() + " символов");
            Log.d("SendRemote", "📄 Содержимое JSON: " + payload);

            Log.d("SendRemote", "🔄 Запуск потока отправки...");

            // СОЗДАЕМ ФИНАЛЬНЫЕ ПЕРЕМЕННЫЕ ДЛЯ ЛЯМБДА-ВЫРАЖЕНИЯ
            final String finalWidgetTitle = finalWeatherItem.getTitle();
            final String finalPayload = payload;

            new Thread(() -> {
                Log.d("SendRemote", "🧵 Поток отправки запущен");
                boolean success = false;
                String errorMessage = "";

                try {
                    Log.d("SendRemote", "🔌 Попытка подключения к " + connectedDeviceIp + ":8080");

                    Socket socket = new Socket(connectedDeviceIp, 8080);
                    Log.d("SendRemote", "✅ Сокет создан успешно");

                    OutputStream outputStream = socket.getOutputStream();
                    Log.d("SendRemote", "✅ OutputStream получен");

                    byte[] payloadBytes = finalPayload.getBytes("UTF-8");
                    Log.d("SendRemote", "📨 Отправка " + payloadBytes.length + " байт данных");

                    outputStream.write(payloadBytes);
                    Log.d("SendRemote", "✅ Данные записаны в поток");

                    outputStream.flush();
                    Log.d("SendRemote", "✅ Поток очищен");

                    outputStream.close();
                    Log.d("SendRemote", "✅ Поток закрыт");

                    socket.close();
                    Log.d("SendRemote", "✅ Сокет закрыт");

                    success = true;
                    Log.d("SendRemote", "🎉 ДАННЫЕ УСПЕШНО ОТПРАВЛЕНЫ НА УСТРОЙСТВО");

                } catch (java.net.ConnectException e) {
                    errorMessage = "Не удалось подключиться к устройству: " + e.getMessage();
                    Log.e("SendRemote", "❌ ОШИБКА ПОДКЛЮЧЕНИЯ: " + errorMessage, e);
                } catch (java.net.SocketTimeoutException e) {
                    errorMessage = "Таймаут подключения: " + e.getMessage();
                    Log.e("SendRemote", "❌ ТАЙМАУТ ПОДКЛЮЧЕНИЯ: " + errorMessage, e);
                } catch (java.io.IOException e) {
                    errorMessage = "Ошибка ввода-вывода: " + e.getMessage();
                    Log.e("SendRemote", "❌ ОШИБКА IO: " + errorMessage, e);
                } catch (Exception e) {
                    errorMessage = "Неизвестная ошибка: " + e.getMessage();
                    Log.e("SendRemote", "❌ НЕИЗВЕСТНАЯ ОШИБКА: " + errorMessage, e);
                }

                final boolean finalSuccess = success;
                final String finalErrorMessage = errorMessage;

                Log.d("SendRemote", "📊 РЕЗУЛЬТАТ ОТПРАВКИ:");
                Log.d("SendRemote", "✅ Успех: " + finalSuccess);
                Log.d("SendRemote", "❌ Ошибка: " + finalErrorMessage);

                runOnUiThread(() -> {
                    if (finalSuccess) {
                        Log.d("SendRemote", "🎯 УВЕДОМЛЕНИЕ: Погода отправлена на зеркало: " + finalWidgetTitle);
                        Toast.makeText(add_vidgets.this, "✅ Погода отправлена на зеркало: " + finalWidgetTitle, Toast.LENGTH_SHORT).show();
                    } else {
                        Log.e("SendRemote", "🎯 УВЕДОМЛЕНИЕ: Не удалось отправить погоду: " + finalErrorMessage);
                        Toast.makeText(add_vidgets.this, "❌ Не удалось отправить погоду: " + finalErrorMessage, Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();

            Log.d("SendRemote", "🧵 Поток отправки запущен в фоне");

        } catch (JSONException e) {
            Log.e("SendRemote", "❌ ОШИБКА ФОРМИРОВАНИЯ JSON", e);
            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "Ошибка формирования данных погоды: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        } catch (Exception e) {
            Log.e("SendRemote", "❌ КРИТИЧЕСКАЯ ОШИБКА", e);
            runOnUiThread(() -> {
                Toast.makeText(add_vidgets.this, "Критическая ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }

        Log.d("SendRemote", "🏁 === ЗАВЕРШЕНИЕ ОТПРАВКИ ПОГОДЫ ===");
    }

    // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С ВАЛЮТОЙ ====================
    private WidgetItem createCurrencyWidgetWithRealData() {
        int selectedPosition = currencySpinner.getSelectedItemPosition();
        if (selectedPosition < 0 || selectedPosition >= availableCurrencies.size()) {
            Toast.makeText(add_vidgets.this, "Выберите валюту для отправки", Toast.LENGTH_SHORT).show();
            return null;
        }

        CurrencyData.Currency selectedCurrency = availableCurrencies.get(selectedPosition);
        double rate = selectedCurrency.getValue();
        double previous = selectedCurrency.getPrevious();
        double change = rate - previous;
        String changeText = String.format("%s%.2f", change >= 0 ? "+" : "", change);

        String changeInfo;
        if (change > 0) {
            changeInfo = "↗ Рост на " + changeText;
        } else if (change < 0) {
            changeInfo = "↘ Падение на " + changeText.replace("+", "");
        } else {
            changeInfo = "→ Без изменений";
        }

        return new WidgetItem(
                0,
                "currency",
                selectedCurrency.getCharCode() + "/RUB",
                String.format("%.2f", rate),
                changeInfo
        );
    }

    private void sendCurrencyWidgetToDevice(WidgetItem currencyItem) {
        if (currencyItem == null || !isConnected) {
            Toast.makeText(add_vidgets.this, "Ошибка: данные валюты не получены", Toast.LENGTH_SHORT).show();
            return;
        }

        // Сохраняем локально для истории
        saveWidget(currencyItem);
        saveWidgetToSharedPrefs(currencyItem);

        try {
            JSONObject json = new JSONObject();
            json.put("type", currencyItem.getType());
            json.put("title", currencyItem.getTitle());
            json.put("data", currencyItem.getData());
            json.put("additionalInfo", currencyItem.getAdditionalInfo());
            json.put("timestamp", System.currentTimeMillis());

            String payload = json.toString();
            Log.d("SendRemote", "📨 Отправка валюты: " + payload);

            new Thread(() -> {
                boolean success = false;
                try {
                    Socket socket = new Socket(connectedDeviceIp, 8080);
                    OutputStream outputStream = socket.getOutputStream();
                    outputStream.write(payload.getBytes("UTF-8"));
                    outputStream.flush();
                    outputStream.close();
                    socket.close();
                    success = true;
                    Log.d("SendRemote", "✅ Валюта успешно отправлена");
                } catch (Exception e) {
                    Log.e("SendRemote", "❌ Ошибка отправки валюты", e);
                }

                final boolean finalSuccess = success;
                final String finalWidgetTitle = currencyItem.getTitle();

                runOnUiThread(() -> {
                    if (finalSuccess) {
                        Toast.makeText(add_vidgets.this, "✅ Валюта отправлена на зеркало: " + finalWidgetTitle, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(add_vidgets.this, "❌ Не удалось отправить валюту на зеркало", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();

        } catch (Exception e) {
            Log.e("SendRemote", "Ошибка формирования JSON для валюты", e);
            Toast.makeText(add_vidgets.this, "Ошибка формирования данных валюты", Toast.LENGTH_SHORT).show();
        }
    }

    // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С QR-КОДОМ ====================
    private void scanQRCode() {
        Log.d("QRScan", "Начало процесса сканирования QR-кода");
        if (checkCameraPermission()) {
            startQRScan();
        } else {
            Log.d("QRScan", "Запрашиваем разрешение на камеру");
            requestCameraPermission();
        }
    }

    private boolean checkCameraPermission() {
        boolean hasPermission = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
        Log.d("QRScan", "Разрешение на камеру: " + (hasPermission ? "есть" : "нет"));
        return hasPermission;
    }

    private void requestCameraPermission() {
        Log.d("QRScan", "Запрос разрешения на камеру");
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                CAMERA_PERMISSION_REQUEST_CODE);
    }

    private void startQRScan() {
        try {
            Log.d("QRScan", "Запуск сканера QR-кодов");
            IntentIntegrator integrator = new IntentIntegrator(this);
            integrator.setPrompt("Сканируйте QR-код с устройства Smart Mirror\nНаведите камеру на QR-код");
            integrator.setOrientationLocked(true);
            integrator.setBeepEnabled(true);
            integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
            integrator.setCameraId(0);
            integrator.setTimeout(30000);
            integrator.setBarcodeImageEnabled(false);
            integrator.setCaptureActivity(PortraitCaptureActivity.class);
            Log.d("QRScan", "Инициирование сканирования");
            integrator.initiateScan();
        } catch (Exception e) {
            Log.e("QRScan", "Критическая ошибка при запуске сканирования", e);
            showCameraErrorDialog(e.getMessage());
        }
    }

    private void showCameraErrorDialog(String errorMessage) {
        new AlertDialog.Builder(this)
                .setTitle("Ошибка камеры")
                .setMessage("Не удалось запустить камеру для сканирования QR-кода.\n\n" +
                        "Причина: " + (errorMessage != null ? errorMessage : "Неизвестная ошибка") + "\n\n" +
                        "Проверьте:\n" +
                        "• Разрешение на использование камеры\n" +
                        "• Доступность камеры\n" +
                        "• Другие приложения, использующие камеру")
                .setPositiveButton("Повторить", (dialog, which) -> {
                    Log.d("QRScan", "Повторная попытка сканирования");
                    scanQRCode();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void processScannedQRCode(String qrContent) {
        Log.d("QRScan", "Обработка QR-кода: " + qrContent);
        if (isValidIpAddressWithPort(qrContent)) {
            Log.d("QRScan", "Обнаружен формат IP:PORT");
            connectToDevice(qrContent);
        } else if (isValidIpAddress(qrContent)) {
            Log.d("QRScan", "Обнаружен формат IP, добавляем порт по умолчанию");
            connectToDevice(qrContent + ":8080");
        } else {
            Log.e("QRScan", "Неверный формат QR-кода: " + qrContent);
            showInvalidQRDialog(qrContent);
        }
    }

    private void showInvalidQRDialog(String qrContent) {
        new AlertDialog.Builder(this)
                .setTitle("Неверный QR-код")
                .setMessage("Сканированный QR-код содержит неверные данные:\n\n" +
                        qrContent + "\n\n" +
                        "QR-код должен содержать IP-адрес устройства Smart Mirror в формате:\n" +
                        "• 192.168.1.100:8080\n" +
                        "• 192.168.1.100\n\n" +
                        "Убедитесь, что сканируете правильный QR-код.")
                .setPositiveButton("Сканировать снова", (dialog, which) -> {
                    Log.d("QRScan", "Повторное сканирование после неверного QR-кода");
                    scanQRCode();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d("Permissions", "onRequestPermissionsResult: requestCode=" + requestCode +
                ", grantResults.length=" + (grantResults.length > 0 ? grantResults[0] : "empty"));

        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permissions", "Разрешение на камеру получено");
                Toast.makeText(add_vidgets.this, "Разрешение на камеру получено", Toast.LENGTH_SHORT).show();
                startQRScan();
            } else {
                Log.w("Permissions", "Разрешение на камеру отклонено");
                Toast.makeText(add_vidgets.this,
                        "Для сканирования QR-кодов необходимо разрешение на использование камеры",
                        Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            } else {
                Toast.makeText(add_vidgets.this, "Разрешение на местоположение отклонено", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ==================== ВАЛИДАЦИЯ IP-АДРЕСОВ ====================
    private boolean isValidIpAddressWithPort(String text) {
        String ipPortPattern = "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?):([0-9]{1,5})$";
        boolean isValid = text.matches(ipPortPattern);
        Log.d("IPValidation", "Проверка IP:PORT '" + text + "': " + isValid);
        return isValid;
    }

    private boolean isValidIpAddress(String ip) {
        String ipPattern = "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
        boolean isValid = ip.matches(ipPattern);
        Log.d("IPValidation", "Проверка IP '" + ip + "': " + isValid);
        return isValid;
    }

    // ==================== СЕТЕВОЕ ВЗАИМОДЕЙСТВИЕ ====================
    private void connectToDevice(String ipWithPort) {
        Log.d("Connection", "Подключение к: " + ipWithPort);
        String[] parts = ipWithPort.split(":");
        String ipAddress = parts[0];
        int port = parts.length > 1 ? Integer.parseInt(parts[1]) : 8080;

        connectionStatus.setText("Подключение к " + ipAddress + ":" + port + "...");
        connectionStatus.setVisibility(View.VISIBLE);

        new Thread(() -> {
            try {
                Log.d("Connection", "Проверка доступности " + ipAddress + ":" + port);
                boolean isReachable = networkManager.testConnection(ipAddress, port);

                runOnUiThread(() -> {
                    if (isReachable) {
                        connectedDeviceIp = ipAddress;
                        isConnected = true;
                        connectionStatus.setText("Подключено к " + ipAddress + ":" + port);
                        Toast.makeText(add_vidgets.this, "✅ Успешно подключено к устройству в локальной сети", Toast.LENGTH_SHORT).show();
                        updateConnectionUI();
                        Log.d("Connection", "✅ Успешное подключение к " + ipAddress + ":" + port);
                    } else {
                        connectionStatus.setText("Устройство недоступно");
                        String errorMsg = "❌ Устройство недоступно\n" +
                                "IP: " + ipAddress + ":" + port + "\n" +
                                "Убедитесь, что:\n" +
                                "• Оба устройства в одной Wi-Fi сети\n" +
                                "• Smart Mirror приложение запущено\n" +
                                "• Брандмауэр разрешает подключения";
                        Toast.makeText(add_vidgets.this, errorMsg, Toast.LENGTH_LONG).show();
                        resetConnection();
                        Log.e("Connection", "❌ Устройство недоступно: " + ipAddress + ":" + port);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    connectionStatus.setText("Ошибка подключения");
                    String errorMsg = "❌ Ошибка подключения: " + e.getMessage() + "\n" +
                            "Проверьте:\n" +
                            "• Подключение к Wi-Fi\n" +
                            "• Правильность IP адреса\n" +
                            "• Запущено ли приложение Smart Mirror";
                    Toast.makeText(add_vidgets.this, errorMsg, Toast.LENGTH_LONG).show();
                    resetConnection();
                    Log.e("Connection", "❌ Ошибка подключения: " + e.getMessage());
                });
            }
        }).start();
    }

    private void sendWidgetsToDevice() {
        if (connectedDeviceIp == null || !isConnected || widgetItems.isEmpty()) {
            Log.e("SendWidgets", "❌ Не могу отправить: connected=" + isConnected + ", ip=" + connectedDeviceIp + ", widgets=" + widgetItems.size());
            Toast.makeText(add_vidgets.this, "Нет подключения или виджетов для отправки", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.d("SendWidgets", "=== НАЧАЛО ОТПРАВКИ ВИДЖЕТОВ ===");
        Log.d("SendWidgets", "IP: " + connectedDeviceIp + ", Виджетов: " + widgetItems.size());

        new Thread(() -> {
            boolean isReachable = networkManager.testConnection(connectedDeviceIp, 8080);

            runOnUiThread(() -> {
                if (!isReachable) {
                    Toast.makeText(add_vidgets.this, "❌ Устройство недоступно. Проверьте подключение.", Toast.LENGTH_LONG).show();
                    return;
                }
                startSendingWidgets();
            });
        }).start();
    }

    private void startSendingWidgets() {
        Toast.makeText(add_vidgets.this, "Отправка " + widgetItems.size() + " виджетов...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            int successCount = 0;
            int errorCount = 0;

            try {
                saveAllWidgetsToSharedPrefs();
                Log.d("SendWidgets", "✅ Виджеты сохранены в SharedPreferences");

                for (int i = 0; i < widgetItems.size(); i++) {
                    WidgetItem widgetItem = widgetItems.get(i);

                    Log.d("SendWidgets", "Отправка " + (i + 1) + "/" + widgetItems.size() + ": " + widgetItem.getTitle());

                    // Формируем JSON для отправки
                    JSONObject json = new JSONObject();
                    json.put("type", widgetItem.getType());
                    json.put("title", widgetItem.getTitle());
                    json.put("data", widgetItem.getData());
                    json.put("additionalInfo", widgetItem.getAdditionalInfo());
                    json.put("timestamp", System.currentTimeMillis());

                    String payload = json.toString();
                    boolean success = false;

                    try {
                        Socket socket = new Socket(connectedDeviceIp, 8080);
                        OutputStream outputStream = socket.getOutputStream();
                        outputStream.write(payload.getBytes("UTF-8"));
                        outputStream.flush();
                        outputStream.close();
                        socket.close();
                        success = true;
                        Log.d("SendWidgets", "✅ Успешно отправлен: " + widgetItem.getTitle());
                    } catch (Exception e) {
                        Log.e("SendWidgets", "❌ Ошибка отправки: " + widgetItem.getTitle(), e);
                    }

                    if (success) {
                        successCount++;
                    } else {
                        errorCount++;
                    }

                    Thread.sleep(500);
                }

                final int finalSuccess = successCount;
                final int finalError = errorCount;

                runOnUiThread(() -> {
                    String message = "Отправка завершена!\nУспешно: " + finalSuccess;
                    if (finalError > 0) {
                        message += "\nОшибок: " + finalError;
                    }
                    Toast.makeText(add_vidgets.this, message, Toast.LENGTH_LONG).show();
                    Log.d("SendWidgets", "=== РЕЗУЛЬТАТ: успешно=" + finalSuccess + ", ошибок=" + finalError);
                });

            } catch (Exception e) {
                Log.e("SendWidgets", "❌ Критическая ошибка отправки", e);
                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "Ошибка отправки: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    private void resetConnection() {
        connectedDeviceIp = null;
        isConnected = false;
        updateConnectionUI();
    }

    private void updateConnectionUI() {
        if (isConnected && connectedDeviceIp != null) {
            connectionStatus.setText("Подключено к " + connectedDeviceIp);
            connectionStatus.setVisibility(View.VISIBLE);
            sendWidgetsBtn.setEnabled(true);
            testSendCurrencyBtn.setEnabled(true);
            testSendWeatherBtn.setEnabled(true);
            scanQrBtn.setEnabled(false);
        } else {
            connectionStatus.setVisibility(View.GONE);
            sendWidgetsBtn.setEnabled(false);
            testSendCurrencyBtn.setEnabled(false);
            testSendWeatherBtn.setEnabled(false);
            scanQrBtn.setEnabled(true);
        }
    }

    // ==================== МЕТОДЫ ДЛЯ РАБОТЫ С ПОГОДОЙ ====================
    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        showWeatherLoading(true);
        weatherError.setVisibility(View.GONE);

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            Log.d("Location", "📍 Получены координаты: " + location.getLatitude() + ", " + location.getLongitude());
                            getWeatherByCoordinates(location.getLatitude(), location.getLongitude());
                        } else {
                            showWeatherLoading(false);
                            weatherError.setText("Не удалось определить местоположение. Попробуйте включить GPS");
                            weatherError.setVisibility(View.VISIBLE);
                            Log.e("Location", "❌ Location is null");

                            // Пробуем запросить обновление местоположения
                            requestNewLocation();
                        }
                    }
                });
    }

    // Новый метод для запроса свежего местоположения
    private void requestNewLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Log.d("Location", "🔄 Запрос свежего местоположения");

        fusedLocationClient.getCurrentLocation(
                com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY,
                null
        ).addOnSuccessListener(this, location -> {
            if (location != null) {
                Log.d("Location", "📍 Получены свежие координаты: " + location.getLatitude() + ", " + location.getLongitude());
                getWeatherByCoordinates(location.getLatitude(), location.getLongitude());
            } else {
                showWeatherLoading(false);
                weatherError.setText("Не удалось получить текущее местоположение. Попробуйте ручной ввод города");
                weatherError.setVisibility(View.VISIBLE);
                Log.e("Location", "❌ Fresh location is also null");
            }
        }).addOnFailureListener(e -> {
            showWeatherLoading(false);
            weatherError.setText("Ошибка получения местоположения: " + e.getMessage());
            weatherError.setVisibility(View.VISIBLE);
            Log.e("Location", "❌ Ошибка получения местоположения", e);
        });
    }

    private void getWeatherByCoordinates(double latitude, double longitude) {
        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";

        Log.d("Weather", "🌤️ Запрос погоды по координатам: " + latitude + ", " + longitude);

        Call<WeatherData> call = weatherApi.getCurrentWeatherByCoords(
                latitude, longitude, "metric", "ru", apiKey
        );

        call.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData currentData = response.body();

                    // Теперь запрашиваем прогноз по координатам
                    fetchWeatherForecastByCoords(latitude, longitude, currentData);
                } else {
                    showWeatherLoading(false);
                    Log.e("Weather", "❌ Ошибка API: " + response.code() + " - " + response.message());
                    handleWeatherError(response);
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                showWeatherLoading(false);
                String errorMsg = "Ошибка сети: " + t.getMessage();
                weatherError.setText(errorMsg);
                weatherError.setVisibility(View.VISIBLE);
                Log.e("Weather", "❌ Ошибка сети при получении погоды", t);
            }
        });
    }

    private void fetchWeatherForecastByCoords(double lat, double lon, WeatherData currentData) {
        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";

        // Теперь этот метод будет работать, так как мы добавили его в WeatherApi
        Call<WeatherData.ForecastResponse> forecastCall = weatherApi.getWeatherForecastByCoords(lat, lon, "metric", "ru", apiKey);
        forecastCall.enqueue(new Callback<WeatherData.ForecastResponse>() {
            @Override
            public void onResponse(Call<WeatherData.ForecastResponse> call, Response<WeatherData.ForecastResponse> response) {
                showWeatherLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData.ForecastResponse forecastResponse = response.body();
                    List<WeatherData.ForecastItem> forecastItems = forecastResponse.getList();

                    if (forecastItems != null && !forecastItems.isEmpty()) {
                        Log.d("Weather", "✅ Прогноз по координатам получен: " + forecastItems.size() + " записей");

                        // Берем первые 3 прогноза
                        List<WeatherData.ForecastItem> nextForecasts = forecastItems.subList(0, Math.min(3, forecastItems.size()));

                        processWeatherData(currentData, nextForecasts);
                    } else {
                        Log.e("Weather", "❌ Пустой прогноз по координатам");
                        processWeatherData(currentData, null);
                    }
                } else {
                    Log.e("Weather", "❌ Ошибка получения прогноза по координатам: " + response.code());
                    processWeatherData(currentData, null);
                }
            }

            @Override
            public void onFailure(Call<WeatherData.ForecastResponse> call, Throwable t) {
                showWeatherLoading(false);
                Log.e("Weather", "❌ Ошибка сети при получении прогноза по координатам", t);
                processWeatherData(currentData, null);
            }
        });
    }

    private void fetchWeatherByCity(String city) {
        showWeatherLoading(true);
        weatherError.setVisibility(View.GONE);

        String apiKey = "d3d4bf2730bf739078a14705c3a7c1b9";

        Log.d("Weather", "🌤️ Запрос погоды для города: " + city);

        Call<WeatherData> call = weatherApi.getCurrentWeather(city, "metric", "ru", apiKey);
        call.enqueue(new Callback<WeatherData>() {
            @Override
            public void onResponse(Call<WeatherData> call, Response<WeatherData> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherData data = response.body();

                    // Теперь запрашиваем прогноз
                    fetchWeatherForecast(city, data);
                } else {
                    showWeatherLoading(false);
                    Log.e("Weather", "❌ Ошибка API для города " + city + ": " + response.code() + " - " + response.message());
                    handleWeatherError(response);
                }
            }

            @Override
            public void onFailure(Call<WeatherData> call, Throwable t) {
                showWeatherLoading(false);
                String errorMsg = "Ошибка сети: " + t.getMessage();
                weatherError.setText(errorMsg);
                weatherError.setVisibility(View.VISIBLE);
                Log.e("Weather", "❌ Ошибка сети для города " + city, t);
            }
        });
    }

    private void addWeatherWidgetToHomeScreen(String city, String temp, String description) {
        SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("weather_city", city);
        editor.putString("weather_temp", temp);
        editor.putString("weather_description", description);
        editor.putLong("last_weather_update", System.currentTimeMillis());
        editor.apply();
        pinWidgetToHomeScreen(WeatherWidget.class, "Погода в " + city);
    }

    private void handleWeatherError(Response<WeatherData> response) {
        String errorMsg;
        switch (response.code()) {
            case 401:
                errorMsg = "Ошибка API ключа. Проверьте ключ OpenWeatherMap";
                Log.e("Weather", "❌ Неверный API ключ!");
                break;
            case 404:
                errorMsg = "Город не найден. Проверьте написание";
                break;
            case 429:
                errorMsg = "Слишком много запросов. Подождите немного";
                break;
            case 500:
                errorMsg = "Ошибка сервера OpenWeatherMap";
                break;
            case 502:
                errorMsg = "Сервис временно недоступен";
                break;
            case 503:
                errorMsg = "Сервис перегружен";
                break;
            default:
                errorMsg = "Ошибка API: " + response.code();
        }
        weatherError.setText(errorMsg);
        weatherError.setVisibility(View.VISIBLE);
    }

    // ==================== СОХРАНЕНИЕ В SHAREDPREFERENCES ====================
    private void saveWidgetToSharedPrefs(WidgetItem widget) {
        try {
            SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            String baseKey = "widget_" + System.currentTimeMillis() + "_" + widget.getType();

            editor.putString(baseKey + "_type", widget.getType());
            editor.putString(baseKey + "_title", widget.getTitle());
            editor.putString(baseKey + "_data", widget.getData());
            editor.putString(baseKey + "_info", widget.getAdditionalInfo());
            editor.putLong(baseKey + "_timestamp", System.currentTimeMillis());

            editor.apply();
            Log.d("SharedPrefs", "Виджет сохранен в SharedPreferences: " + widget.getTitle());
        } catch (Exception e) {
            Log.e("SharedPrefs", "Ошибка сохранения в SharedPreferences", e);
        }
    }

    private void saveAllWidgetsToSharedPrefs() {
        try {
            clearWidgetsFromSharedPrefs();
            for (WidgetItem widget : widgetItems) {
                saveWidgetToSharedPrefs(widget);
            }
            Log.d("SharedPrefs", "Все виджеты сохранены в SharedPreferences: " + widgetItems.size() + " шт.");
        } catch (Exception e) {
            Log.e("SharedPrefs", "Ошибка сохранения всех виджетов", e);
        }
    }

    private void clearWidgetsFromSharedPrefs() {
        try {
            SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();
            Log.d("SharedPrefs", "Все виджеты удалены из SharedPreferences");
        } catch (Exception e) {
            Log.e("SharedPrefs", "Ошибка очистки SharedPreferences", e);
        }
    }

    private void deleteWidgetFromSharedPrefs(WidgetItem widget) {
        try {
            SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            Map<String, ?> allEntries = prefs.getAll();

            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                String key = entry.getKey();
                if (key.endsWith("_title") && entry.getValue().equals(widget.getTitle())) {
                    String baseKey = key.replace("_title", "");
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.remove(baseKey + "_type");
                    editor.remove(baseKey + "_title");
                    editor.remove(baseKey + "_data");
                    editor.remove(baseKey + "_info");
                    editor.remove(baseKey + "_timestamp");
                    editor.apply();
                    Log.d("SharedPrefs", "Виджет удален из SharedPreferences: " + widget.getTitle());
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("SharedPrefs", "Ошибка удаления виджета из SharedPreferences", e);
        }
    }

    // ==================== СУЩЕСТВУЮЩИЕ МЕТОДЫ ====================
    private void setupCurrencySpinner() {
        List<String> tempList = new ArrayList<>();
        tempList.add("Загрузка валют...");
        currencyAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tempList);
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        currencySpinner.setAdapter(currencyAdapter);
    }

    private void loadAvailableCurrencies() {
        showCurrencyLoading(true);
        currencyError.setVisibility(View.GONE);

        Call<CurrencyData> call = currencyApi.getCurrencyRates();
        call.enqueue(new Callback<CurrencyData>() {
            @Override
            public void onResponse(Call<CurrencyData> call, Response<CurrencyData> response) {
                showCurrencyLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    CurrencyData data = response.body();
                    Map<String, CurrencyData.Currency> valuteMap = data.getValute();

                    if (valuteMap != null) {
                        availableCurrencies.clear();
                        List<String> currencyNames = new ArrayList<>();

                        for (Map.Entry<String, CurrencyData.Currency> entry : valuteMap.entrySet()) {
                            CurrencyData.Currency currency = entry.getValue();
                            availableCurrencies.add(currency);
                            currencyNames.add(currency.getCharCode() + " - " + currency.getName());
                        }

                        runOnUiThread(() -> {
                            currencyAdapter.clear();
                            currencyAdapter.addAll(currencyNames);
                            currencyAdapter.notifyDataSetChanged();
                            Toast.makeText(add_vidgets.this, "Загружено валют: " + availableCurrencies.size(), Toast.LENGTH_SHORT).show();
                        });
                    }
                } else {
                    currencyError.setText("Ошибка загрузки списка валют: " + response.code());
                    currencyError.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<CurrencyData> call, Throwable t) {
                showCurrencyLoading(false);
                currencyError.setText("Ошибка сети: " + t.getMessage());
                currencyError.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setupRecyclerView() {
        adapter = new WidgetsAdapter(widgetItems, this);
        widgetsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        widgetsRecyclerView.setAdapter(adapter);
    }

    private void setupRetrofit() {
        Retrofit weatherRetrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Retrofit currencyRetrofit = new Retrofit.Builder()
                .baseUrl("https://www.cbr-xml-daily.ru/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        weatherApi = weatherRetrofit.create(WeatherApi.class);
        currencyApi = currencyRetrofit.create(CurrencyApi.class);
    }

    private void addCurrencyWidget(CurrencyData.Currency currency) {
        double rate = currency.getValue();
        String name = currency.getName();
        String charCode = currency.getCharCode();

        double previous = currency.getPrevious();
        double change = rate - previous;
        String changeText = String.format("%s%.2f", change >= 0 ? "+" : "", change);

        String changeInfo;
        if (change > 0) {
            changeInfo = "↗ Рост на " + changeText;
        } else if (change < 0) {
            changeInfo = "↘ Падение на " + changeText.replace("+", "");
        } else {
            changeInfo = "→ Без изменений";
        }

        WidgetItem item = new WidgetItem(0, "currency", charCode + " - " + name,
                String.format("%.2f RUB", rate), changeInfo);
        widgetItems.add(item);
        adapter.updateData(widgetItems);
        saveWidget(item);
        saveWidgetToSharedPrefs(item);
        // Локальное добавление: если пользователь выбрал "На это устройство"
        addCurrencyWidgetToHomeScreen(charCode, String.format("%.2f", rate), changeInfo);
        Toast.makeText(add_vidgets.this, "Курс " + charCode + " добавлен", Toast.LENGTH_SHORT).show();
    }

    private void addCurrencyWidgetToHomeScreen(String currencyCode, String rate, String changeInfo) {
        SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("currency_code", currencyCode);
        editor.putString("currency_rate", rate);
        editor.putString("currency_change", changeInfo);
        editor.putLong("last_currency_update", System.currentTimeMillis());
        editor.apply();
        pinWidgetToHomeScreen(CurrencyWidget.class, "Курс " + currencyCode);
    }

    private void pinWidgetToHomeScreen(Class<? extends AppWidgetProvider> widgetClass, String widgetLabel) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            showManualWidgetInstructions(widgetLabel);
            return;
        }

        AppWidgetManager appWidgetManager = getSystemService(AppWidgetManager.class);
        ComponentName widgetComponent = new ComponentName(this, widgetClass);

        if (appWidgetManager.isRequestPinAppWidgetSupported()) {
            requestPinAppWidget(appWidgetManager, widgetComponent, widgetLabel);
        } else {
            showManualWidgetInstructions(widgetLabel);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void requestPinAppWidget(AppWidgetManager appWidgetManager,
                                     ComponentName widgetComponent, String widgetLabel) {
        Intent pinnedWidgetCallbackIntent = new Intent(this, add_vidgets.class);
        pinnedWidgetCallbackIntent.setAction("APPWIDGET_PINNED_" + widgetComponent.getShortClassName());
        pinnedWidgetCallbackIntent.putExtra("widget_label", widgetLabel);

        PendingIntent successCallback = PendingIntent.getActivity(
                this,
                PIN_WIDGET_REQUEST_CODE,
                pinnedWidgetCallbackIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        try {
            boolean success = appWidgetManager.requestPinAppWidget(widgetComponent, null, successCallback);

            if (success) {
                Toast.makeText(add_vidgets.this, "Разрешите добавление виджета в появившемся окне", Toast.LENGTH_SHORT).show();
            } else {
                showManualWidgetInstructions(widgetLabel);
            }
        } catch (Exception e) {
            Log.e("PinWidget", "Ошибка при закреплении виджета", e);
            showManualWidgetInstructions(widgetLabel);
        }
    }

    private void showManualWidgetInstructions(String widgetLabel) {
        String message = "Виджет \"" + widgetLabel + "\" готов к добавлению!\n\n" +
                "Чтобы добавить виджет:\n" +
                "1. Перейдите на главный экран\n" +
                "2. Сделайте долгое нажатие\n" +
                "3. Выберите \"Виджеты\"\n" +
                "4. Найдите \"Smartsy\" и перетащите виджет на экран";
        Toast.makeText(add_vidgets.this, message, Toast.LENGTH_LONG).show();
        updateAllWidgets();
    }

    private void handlePinWidgetCallback() {
        Intent intent = getIntent();
        if (intent != null && intent.getAction() != null && intent.getAction().startsWith("APPWIDGET_PINNED_")) {
            String widgetLabel = intent.getStringExtra("widget_label");
            if (widgetLabel == null) {
                widgetLabel = "виджет";
            }
            Toast.makeText(add_vidgets.this, "Виджет \"" + widgetLabel + "\" успешно добавлен на домашний экран!", Toast.LENGTH_LONG).show();
            updateAllWidgets();
        }
    }

    private void updateAllWidgets() {
        updateWeatherWidgets();
        updateCurrencyWidgets();
        updateNoteWidgets();
    }

    private void updateWeatherWidgets() {
        Intent intent = new Intent(this, com.example.smartsy.Weather.WeatherWidget.class);
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(this)
                .getAppWidgetIds(new ComponentName(this, com.example.smartsy.Weather.WeatherWidget.class));
        if (ids.length > 0) {
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            sendBroadcast(intent);
            Log.d("WeatherWidget", "Обновление виджетов погоды: " + ids.length + " шт.");
        }
    }

    private void updateCurrencyWidgets() {
        Intent intent = new Intent(this, com.example.smartsy.Currency.CurrencyWidget.class);
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(this)
                .getAppWidgetIds(new ComponentName(this, com.example.smartsy.Currency.CurrencyWidget.class));
        if (ids.length > 0) {
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            sendBroadcast(intent);
            Log.d("CurrencyWidget", "Обновление виджетов валют: " + ids.length + " шт.");
        }
    }

    private void updateNoteWidgets() {
        Intent intent = new Intent(this, NoteWidget.class);
        intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(this)
                .getAppWidgetIds(new ComponentName(this, NoteWidget.class));
        if (ids.length > 0) {
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            sendBroadcast(intent);
            Log.d("NoteWidget", "Обновление виджетов заметок: " + ids.length + " шт.");
        }
    }

    @Override
    public void onWidgetDelete(WidgetItem widget) {
        widgetItems.remove(widget);
        adapter.updateData(widgetItems);

        executor.execute(() -> {
            try {
                List<WidgetEntity> allWidgets = database.widgetDao().getAllWidgets();
                for (WidgetEntity entity : allWidgets) {
                    if (entity.title.equals(widget.getTitle()) &&
                            entity.data.equals(widget.getData())) {
                        database.widgetDao().delete(entity);
                        break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    Toast.makeText(add_vidgets.this, "Ошибка удаления виджета", Toast.LENGTH_SHORT).show();
                });
            }
        });

        deleteWidgetFromSharedPrefs(widget);
        Toast.makeText(add_vidgets.this, "Виджет удален", Toast.LENGTH_SHORT).show();
    }

    private void loadSavedWidgets() {
        executor.execute(() -> {
            try {
                List<WidgetEntity> entities = database.widgetDao().getAllWidgets();
                List<WidgetItem> items = new ArrayList<>();
                for (WidgetEntity entity : entities) {
                    items.add(new WidgetItem(entity));
                }

                runOnUiThread(() -> {
                    widgetItems.clear();
                    widgetItems.addAll(items);
                    adapter.updateData(widgetItems);
                    saveAllWidgetsToSharedPrefs();
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void saveWidget(WidgetItem widget) {
        executor.execute(() -> {
            try {
                database.widgetDao().insert(widget.toEntity());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void showWeatherLoading(boolean loading) {
        weatherProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        addWeatherBtn.setEnabled(!loading);
        autoDetectBtn.setEnabled(!loading);
    }

    private void showCurrencyLoading(boolean loading) {
        currencyProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        addCurrencyBtn.setEnabled(!loading);
        refreshCurrencyBtn.setEnabled(!loading);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePinWidgetCallback();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
        if (networkManager != null) {
            networkManager.disconnect();
        }
    }
}