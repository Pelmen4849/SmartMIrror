package com.example.smartsy;

import android.app.Application;

import androidx.room.Room;

public class SmartsyApp extends Application {
    private static SmartsyApp instance;
    private AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        database = Room.databaseBuilder(this, AppDatabase.class, "widgets-db")
                .fallbackToDestructiveMigration()
                .build();
    }

    public static SmartsyApp getInstance() {
        return instance;
    }

    public AppDatabase getDatabase() {
        return database;
    }
}