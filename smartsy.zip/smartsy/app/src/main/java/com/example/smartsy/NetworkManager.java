package com.example.smartsy;

import android.util.Log;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class NetworkManager {
    private static final String TAG = "NetworkManager";
    private static final int CONNECTION_TIMEOUT = 5000; // 5 секунд
    private static final int SOCKET_TIMEOUT = 10000; // 10 секунд

    private Socket currentSocket;

    public NetworkManager() {
        Log.d(TAG, "NetworkManager инициализирован");
    }

    /**
     * Проверка доступности устройства
     */
    public boolean testConnection(String ipAddress, int port) {
        Log.d(TAG, "🔍 Проверка подключения к " + ipAddress + ":" + port);

        Socket socket = null;
        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ipAddress, port), CONNECTION_TIMEOUT);
            socket.setSoTimeout(SOCKET_TIMEOUT);

            boolean isConnected = socket.isConnected() && !socket.isClosed();
            Log.d(TAG, "✅ Устройство доступно: " + isConnected);
            return isConnected;

        } catch (SocketTimeoutException e) {
            Log.e(TAG, "❌ Таймаут подключения к " + ipAddress + ":" + port);
            return false;
        } catch (IOException e) {
            Log.e(TAG, "❌ Ошибка подключения к " + ipAddress + ":" + port + " - " + e.getMessage());
            return false;
        } catch (Exception e) {
            Log.e(TAG, "❌ Неизвестная ошибка при подключении к " + ipAddress + ":" + port, e);
            return false;
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    Log.e(TAG, "Ошибка закрытия сокета", e);
                }
            }
        }
    }

    /**
     * Простая отправка данных на устройство
     */
    public boolean sendDataToDevice(String ipAddress, int port, String data) {
        Log.d(TAG, "📨 Отправка данных на " + ipAddress + ":" + port);
        Log.d(TAG, "📦 Данные: " + data);

        Socket socket = null;
        OutputStream outputStream = null;

        try {
            socket = new Socket();
            socket.connect(new InetSocketAddress(ipAddress, port), CONNECTION_TIMEOUT);
            socket.setSoTimeout(SOCKET_TIMEOUT);

            outputStream = socket.getOutputStream();

            // Отправляем данные как plain text
            byte[] dataBytes = data.getBytes("UTF-8");
            outputStream.write(dataBytes);
            outputStream.flush();

            Log.d(TAG, "✅ Данные успешно отправлены: " + dataBytes.length + " байт");
            return true;

        } catch (SocketTimeoutException e) {
            Log.e(TAG, "❌ Таймаут при отправке данных", e);
            return false;
        } catch (IOException e) {
            Log.e(TAG, "❌ Ошибка ввода-вывода при отправке данных: " + e.getMessage());
            return false;
        } catch (Exception e) {
            Log.e(TAG, "❌ Неизвестная ошибка при отправке данных", e);
            return false;
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                Log.e(TAG, "Ошибка закрытия потоков", e);
            }
        }
    }

    /**
     * Отправка JSON данных на устройство
     */
    public boolean sendJsonData(String ipAddress, int port, String jsonData) {
        return sendDataToDevice(ipAddress, port, jsonData);
    }

    /**
     * Отправка виджета на устройство (старый API для совместимости)
     */
    public boolean sendWidgetToDevice(String ipAddress, RemoteWidget widget) {
        if (widget == null) {
            Log.e(TAG, "❌ Widget is null");
            return false;
        }

        try {
            String jsonData = widget.toJson();
            return sendDataToDevice(ipAddress, 8080, jsonData);
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка преобразования виджета в JSON", e);
            return false;
        }
    }

    /**
     * Отправка виджета в формате JSON (новый API)
     */
    public boolean sendWidgetJson(String ipAddress, String jsonData) {
        return sendDataToDevice(ipAddress, 8080, jsonData);
    }

    /**
     * Закрытие всех соединений
     */
    public void disconnect() {
        Log.d(TAG, "🔌 Закрытие всех соединений");
        if (currentSocket != null && !currentSocket.isClosed()) {
            try {
                currentSocket.close();
                Log.d(TAG, "✅ Сокет закрыт");
            } catch (IOException e) {
                Log.e(TAG, "❌ Ошибка закрытия сокета", e);
            }
        }
    }

    /**
     * Проверка доступности сети
     */
    public boolean isNetworkAvailable() {
        try {
            // Простая проверка - пытаемся подключиться к Google DNS
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress("8.8.8.8", 53), 2000);
            socket.close();
            Log.d(TAG, "✅ Сеть доступна");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "❌ Сеть недоступна");
            return false;
        }
    }

    /**
     * Пинг устройства
     */
    public boolean pingDevice(String ipAddress, int timeout) {
        try {
            Process process = Runtime.getRuntime().exec("/system/bin/ping -c 1 -W " + timeout + " " + ipAddress);
            int returnCode = process.waitFor();
            boolean reachable = (returnCode == 0);
            Log.d(TAG, "📡 Ping " + ipAddress + ": " + (reachable ? "доступен" : "недоступен"));
            return reachable;
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка ping: " + e.getMessage());
            return false;
        }
    }
}