package com.example.smartsy.Traffic;

import com.google.gson.annotations.SerializedName;

public class TrafficData {
    @SerializedName("result")
    private TrafficResult result;

    public TrafficResult getResult() {
        return result;
    }

    public static class TrafficResult {
        @SerializedName("level")
        private int level;

        @SerializedName("level_name")
        private String levelName;

        @SerializedName("hint")
        private String hint;

        public int getLevel() {
            return level;
        }

        public String getLevelName() {
            return levelName;
        }

        public String getHint() {
            return hint;
        }
    }
}