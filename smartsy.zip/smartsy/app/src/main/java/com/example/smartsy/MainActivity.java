package com.example.smartsy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "SmartsyPrefs";
    private static final String KEY_REMEMBER_ME = "remember_me";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Инициализируем Firebase
        mAuth = FirebaseAuth.getInstance();

        // Инициализируем SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        Button enters = findViewById(R.id.enter);
        Button regs = findViewById(R.id.reg_btn);

        regs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, reg.class);
                startActivity(intent);
            }
        });

        enters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, enter.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Проверяем, включена ли опция "Запомнить меня"
        boolean rememberMe = sharedPreferences.getBoolean(KEY_REMEMBER_ME, false);

        if (rememberMe) {
            // Опция "Запомнить меня" включена - проверяем аутентификацию
            if (mAuth == null) {
                mAuth = FirebaseAuth.getInstance();
            }

            FirebaseUser currentUser = mAuth.getCurrentUser();

            if (currentUser != null && currentUser.isEmailVerified()) {
                // Пользователь вошел и подтвердил email
                Toast.makeText(this, "Добро пожаловать обратно!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, add_vidgets.class);
                startActivity(intent);
                finish();
            }
            // Если пользователь не подтвердил email или не вошел - остаемся на главном экране
        }
        // Если опция "Запомнить меня" выключена - всегда показываем главный экран
    }
}