package com.example.smartsy.Weather;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.smartsy.R;

import java.util.ArrayList;
import java.util.List;

public class WeatherWidgetFactory implements RemoteViewsService.RemoteViewsFactory {

    private Context context;
    private List<WidgetData> widgetDataList;

    public WeatherWidgetFactory(Context context, Intent intent) {
        this.context = context;
    }

    @Override
    public void onCreate() {
        widgetDataList = new ArrayList<>();
    }

    @Override
    public void onDataSetChanged() {
        // Загружаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);
        widgetDataList.clear();

        String city = prefs.getString("city", "");
        String temp = prefs.getString("temp", "");
        String desc = prefs.getString("description", "");

        if (!city.isEmpty() && !temp.isEmpty()) {
            widgetDataList.add(new WidgetData(city, temp, desc));
        }
    }

    @Override
    public void onDestroy() {
        widgetDataList.clear();
    }

    @Override
    public int getCount() {
        return widgetDataList.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        if (position >= widgetDataList.size()) {
            return null;
        }

        WidgetData data = widgetDataList.get(position);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.weather_widget_layout);

        views.setTextViewText(R.id.widget_city, data.city);
        views.setTextViewText(R.id.widget_temp, data.temp);
        views.setTextViewText(R.id.widget_desc, data.description);

        return views;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    // Вспомогательный класс для хранения данных
    private static class WidgetData {
        String city;
        String temp;
        String description;

        WidgetData(String city, String temp, String description) {
            this.city = city;
            this.temp = temp;
            this.description = description;
        }
    }
}