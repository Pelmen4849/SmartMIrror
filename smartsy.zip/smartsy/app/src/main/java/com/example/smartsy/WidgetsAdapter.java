package com.example.smartsy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsy.Widget.WidgetItem;

import java.util.List;

public class WidgetsAdapter extends RecyclerView.Adapter<WidgetsAdapter.ViewHolder> {

    private List<WidgetItem> widgetItems;

    public WidgetsAdapter(List<WidgetItem> widgetItems) {
        this.widgetItems = widgetItems;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_widget, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WidgetItem item = widgetItems.get(position);
        holder.title.setText(item.getTitle());
        holder.data.setText(item.getData());
        holder.additionalInfo.setText(item.getAdditionalInfo());
    }

    @Override
    public int getItemCount() {
        return widgetItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, data, additionalInfo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.widgetTitle);
            data = itemView.findViewById(R.id.widgetData);
            additionalInfo = itemView.findViewById(R.id.widgetAdditionalInfo);
        }
    }

    public void updateData(List<WidgetItem> newItems) {
        widgetItems = newItems;
        notifyDataSetChanged();
    }
}