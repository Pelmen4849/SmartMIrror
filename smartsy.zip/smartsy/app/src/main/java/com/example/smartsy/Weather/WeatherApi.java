package com.example.smartsy.Weather;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherApi {
    // По названию города
    @GET("data/2.5/weather")
    Call<WeatherData> getCurrentWeather(
            @Query("q") String city,
            @Query("units") String units,
            @Query("lang") String lang,
            @Query("appid") String apiKey
    );

    // По координатам
    @GET("data/2.5/weather")
    Call<WeatherData> getCurrentWeatherByCoords(
            @Query("lat") double lat,
            @Query("lon") double lon,
            @Query("units") String units,
            @Query("lang") String lang,
            @Query("appid") String apiKey
    );

    // Прогноз погоды по названию города
    @GET("data/2.5/forecast")
    Call<WeatherData.ForecastResponse> getWeatherForecast(
            @Query("q") String city,
            @Query("units") String units,
            @Query("lang") String lang,
            @Query("appid") String apiKey
    );

    // Прогноз погоды по координатам - ДОБАВЛЕННЫЙ МЕТОД
    @GET("data/2.5/forecast")
    Call<WeatherData.ForecastResponse> getWeatherForecastByCoords(
            @Query("lat") double lat,
            @Query("lon") double lon,
            @Query("units") String units,
            @Query("lang") String lang,
            @Query("appid") String apiKey
    );
}