package com.example.smartsy.Currency;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import com.example.smartsy.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CurrencyWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.currency_widget_layout);

        String currencyCode = prefs.getString("currency_code", "USD");
        String rate = prefs.getString("currency_rate", "0.00");
        String change = prefs.getString("currency_change", "");
        long lastUpdate = prefs.getLong("last_currency_update", 0);


        String updateTime = "Обновлено: " + getFormattedTime(lastUpdate);

        views.setTextViewText(R.id.widget_currency_code, currencyCode);
        views.setTextViewText(R.id.widget_currency_rate, rate + " RUB");
        views.setTextViewText(R.id.widget_currency_change, change);
        views.setTextViewText(R.id.widget_update_time, updateTime);


        Intent updateIntent = new Intent(context, CurrencyWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = {appWidgetId};
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.widget_container, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static String getFormattedTime(long timestamp) {
        if (timestamp == 0) return "никогда";

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    @Override
    public void onEnabled(Context context) {
        // При первом добавлении виджета
    }

    @Override
    public void onDisabled(Context context) {
        // Когда последний виджет удален
    }
}