package com.example.smartsy.Currency;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class CurrencyData {
    @SerializedName("Valute")
    private Map<String, Currency> valute;

    public Map<String, Currency> getValute() { return valute; }

    public static class Currency {
        @SerializedName("CharCode")
        private String charCode;

        @SerializedName("Name")
        private String name;

        @SerializedName("Value")
        private double value;

        @SerializedName("Previous")
        private double previous;

        public String getCharCode() { return charCode; }
        public String getName() { return name; }
        public double getValue() { return value; }
        public double getPrevious() { return previous; }
    }
}