package com.example.smartsy.Weather;

import com.google.gson.annotations.SerializedName;

public class IpLocation {
    @SerializedName("lat")
    private double latitude;

    @SerializedName("lon")
    private double longitude;

    @SerializedName("city")
    private String city;

    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }
    public String getCity() { return city; }
}