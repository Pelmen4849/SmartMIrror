package com.example.smartsy.Widget;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;

@Entity(tableName = "widgets")
public class WidgetEntity {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "type")
    public String type;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "data")
    public String data;

    @ColumnInfo(name = "additional_info")
    public String additionalInfo;

    @ColumnInfo(name = "timestamp")  // Добавляем timestamp
    public long timestamp;

    // Конструктор без ID (для создания новых записей)
    public WidgetEntity(String type, String title, String data, String additionalInfo) {
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
        this.timestamp = System.currentTimeMillis();  // Устанавливаем текущее время
    }

    // Конструктор по умолчанию (обязателен для Room)
    public WidgetEntity() {
    }

    // Геттеры и сеттеры
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}