package com.example.smartsy.Widget;

import android.os.Parcel;
import android.os.Parcelable;

public class WidgetItem implements Parcelable {
    private int id;
    private String type;
    private String title;
    private String data;
    private String additionalInfo;

    // Существующие конструкторы
    public WidgetItem(int id, String type, String title, String data, String additionalInfo) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
    }

    public WidgetItem(String type, String title, String data, String additionalInfo) {
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
    }

    public WidgetItem(WidgetEntity entity) {
        this.id = entity.id;
        this.type = entity.type;
        this.title = entity.title;
        this.data = entity.data;
        this.additionalInfo = entity.additionalInfo;
    }

    // Новый конструктор с 6 параметрами
    public WidgetItem(int id, String type, String title, String data, String additionalInfo, String extraInfo) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
        // extraInfo можно игнорировать или использовать по необходимости
    }

    // Конструктор для Parcel
    protected WidgetItem(Parcel in) {
        id = in.readInt();
        type = in.readString();
        title = in.readString();
        data = in.readString();
        additionalInfo = in.readString();
    }

    public static final Creator<WidgetItem> CREATOR = new Creator<WidgetItem>() {
        @Override
        public WidgetItem createFromParcel(Parcel in) {
            return new WidgetItem(in);
        }

        @Override
        public WidgetItem[] newArray(int size) {
            return new WidgetItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(type);
        dest.writeString(title);
        dest.writeString(data);
        dest.writeString(additionalInfo);
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getAdditionalInfo() { return additionalInfo; }
    public void setAdditionalInfo(String additionalInfo) { this.additionalInfo = additionalInfo; }

    public WidgetEntity toEntity() {
        WidgetEntity entity = new WidgetEntity();
        entity.id = this.id;
        entity.type = this.type;
        entity.title = this.title;
        entity.data = this.data;
        entity.additionalInfo = this.additionalInfo;
        return entity;
    }
}