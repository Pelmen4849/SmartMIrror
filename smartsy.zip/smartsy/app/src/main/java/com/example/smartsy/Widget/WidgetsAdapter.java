package com.example.smartsy.Widget;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartsy.R;

import java.util.List;

public class WidgetsAdapter extends RecyclerView.Adapter<WidgetsAdapter.ViewHolder> {

    private List<WidgetItem> widgetItems;
    private OnWidgetDeleteListener deleteListener;

    public interface OnWidgetDeleteListener {
        void onWidgetDelete(WidgetItem widget);
    }

    public WidgetsAdapter(List<WidgetItem> widgetItems, OnWidgetDeleteListener deleteListener) {
        this.widgetItems = widgetItems;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_widget, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WidgetItem item = widgetItems.get(position);
        holder.title.setText(item.getTitle());
        holder.data.setText(item.getData());
        holder.additionalInfo.setText(item.getAdditionalInfo());

        holder.deleteBtn.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onWidgetDelete(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return widgetItems.size();
    }

    public void updateData(List<WidgetItem> newItems) {
        widgetItems = newItems;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, data, additionalInfo;
        ImageButton deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.widgetTitle);
            data = itemView.findViewById(R.id.widgetData);
            additionalInfo = itemView.findViewById(R.id.widgetAdditionalInfo);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
        }
    }
}