package com.example.smartsy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class enter extends AppCompatActivity {

    private TextInputEditText emailEditText, passwordEditText;
    private TextInputLayout emailLayout, passwordLayout;
    private CheckBox rememberMeCheckbox;
    private Button loginButton, registerRedirectButton, forgotPasswordButton;
    private ProgressBar progressBar;
    private TextView errorTextView;

    private FirebaseAuth mAuth;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "SmartsyPrefs";
    private static final String KEY_REMEMBER_ME = "remember_me";
    private static final String KEY_EMAIL = "saved_email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_enter);

        // Инициализация Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Инициализация SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Инициализация views
        initViews();

        // Загружаем сохраненные данные
        loadSavedCredentials();

        // Настройка слушателей
        setupListeners();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initViews() {
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        rememberMeCheckbox = findViewById(R.id.rememberMeCheckbox);

        emailLayout = findViewById(R.id.emailLayout);
        passwordLayout = findViewById(R.id.passwordLayout);

        loginButton = findViewById(R.id.loginButton);
        registerRedirectButton = findViewById(R.id.registerRedirectButton);
        forgotPasswordButton = findViewById(R.id.forgotPasswordButton);

        progressBar = findViewById(R.id.progressBar);
        errorTextView = findViewById(R.id.errorTextView);
    }

    private void loadSavedCredentials() {
        boolean rememberMe = sharedPreferences.getBoolean(KEY_REMEMBER_ME, false);

        if (rememberMe) {
            String savedEmail = sharedPreferences.getString(KEY_EMAIL, "");
            emailEditText.setText(savedEmail);
            rememberMeCheckbox.setChecked(true);
        }
    }

    private void saveCredentials(String email) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_REMEMBER_ME, rememberMeCheckbox.isChecked());

        if (rememberMeCheckbox.isChecked()) {
            editor.putString(KEY_EMAIL, email);
        } else {
            editor.remove(KEY_EMAIL);
        }

        editor.apply();
    }

    private void setupListeners() {
        loginButton.setOnClickListener(v -> attemptLogin());

        registerRedirectButton.setOnClickListener(v -> {
            Intent intent = new Intent(enter.this, reg.class);
            startActivity(intent);
        });

        forgotPasswordButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailLayout.setError("Введите корректный email для восстановления");
            } else {
                resetPassword(email);
            }
        });

        emailEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                clearErrors();
            }
        });

        passwordEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                clearErrors();
            }
        });
    }

    private void attemptLogin() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (validateInput(email, password)) {
            loginUser(email, password);
        }
    }

    private boolean validateInput(String email, String password) {
        boolean isValid = true;

        if (TextUtils.isEmpty(email)) {
            emailLayout.setError("Введите email");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailLayout.setError("Введите корректный email");
            isValid = false;
        } else {
            emailLayout.setError(null);
        }

        if (TextUtils.isEmpty(password)) {
            passwordLayout.setError("Введите пароль");
            isValid = false;
        } else if (password.length() < 6) {
            passwordLayout.setError("Пароль должен содержать минимум 6 символов");
            isValid = false;
        } else {
            passwordLayout.setError(null);
        }

        return isValid;
    }

    private void loginUser(String email, String password) {
        showLoading(true);
        clearErrors();

        if (mAuth == null) {
            mAuth = FirebaseAuth.getInstance();
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    showLoading(false);

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            if (user.isEmailVerified()) {
                                // Сохраняем настройки "Запомнить меня"
                                saveCredentials(email);

                                Toast.makeText(enter.this,
                                        "Вход выполнен успешно!",
                                        Toast.LENGTH_SHORT).show();
                                navigateToMainActivity();
                            } else {
                                showError("Подтвердите email перед входом. Проверьте вашу почту.");
                                mAuth.signOut();
                            }
                        }
                    } else {
                        String errorMessage = "Ошибка входа";
                        if (task.getException() != null) {
                            errorMessage = getErrorMessage(task.getException().getMessage());
                        }
                        showError(errorMessage);
                    }
                });
    }

    private void resetPassword(String email) {
        showLoading(true);

        if (mAuth == null) {
            mAuth = FirebaseAuth.getInstance();
        }

        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    showLoading(false);

                    if (task.isSuccessful()) {
                        Toast.makeText(enter.this,
                                "Инструкции по восстановлению отправлены на email",
                                Toast.LENGTH_LONG).show();
                    } else {
                        showError("Ошибка отправки email восстановления");
                    }
                });
    }

    private String getErrorMessage(String firebaseError) {
        if (firebaseError.contains("invalid login credentials") ||
                firebaseError.contains("no user record")) {
            return "Неверный email или пароль";
        } else if (firebaseError.contains("invalid email")) {
            return "Неверный формат email";
        } else if (firebaseError.contains("network error")) {
            return "Ошибка сети. Проверьте подключение";
        } else if (firebaseError.contains("too many attempts")) {
            return "Слишком много попыток. Попробуйте позже";
        }
        return "Ошибка входа. Попробуйте еще раз";
    }

    private void showLoading(boolean isLoading) {
        if (isLoading) {
            progressBar.setVisibility(View.VISIBLE);
            loginButton.setEnabled(false);
            registerRedirectButton.setEnabled(false);
            forgotPasswordButton.setEnabled(false);
            loginButton.setAlpha(0.5f);
        } else {
            progressBar.setVisibility(View.GONE);
            loginButton.setEnabled(true);
            registerRedirectButton.setEnabled(true);
            forgotPasswordButton.setEnabled(true);
            loginButton.setAlpha(1f);
        }
    }

    private void showError(String message) {
        errorTextView.setText(message);
        errorTextView.setVisibility(View.VISIBLE);
    }

    private void clearErrors() {
        errorTextView.setVisibility(View.GONE);
        errorTextView.setText("");
        emailLayout.setError(null);
        passwordLayout.setError(null);
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(enter.this, add_vidgets.class);
        startActivity(intent);
        finish();
    }

    // Метод для выхода (можно вызвать из других классов)
    public static void logout(SharedPreferences prefs) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_REMEMBER_ME);
        editor.remove(KEY_EMAIL);
        editor.apply();

        FirebaseAuth.getInstance().signOut();
    }
}