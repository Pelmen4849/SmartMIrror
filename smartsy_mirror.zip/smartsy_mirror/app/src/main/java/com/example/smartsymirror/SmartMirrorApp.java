package com.example.smartsymirror;

import android.app.Application;
import android.util.Log;

public class SmartMirrorApp extends Application {
    private static final String TAG = "SmartMirrorApp";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Smart Mirror Application started");

        // Запускаем сервис при запуске приложения
        startForegroundService();
    }

    private void startForegroundService() {
        try {
            // Запускаем сервис который будет принимать подключения
            android.content.Intent serviceIntent = new android.content.Intent(this, ForegroundService.class);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            Log.d(TAG, "Foreground service started from Application");
        } catch (Exception e) {
            Log.e(TAG, "Error starting service from Application: " + e.getMessage());
        }
    }
}