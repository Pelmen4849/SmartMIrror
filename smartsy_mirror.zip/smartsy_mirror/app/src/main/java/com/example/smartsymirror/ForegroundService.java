package com.example.smartsymirror;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ForegroundService extends Service {
    private static final String TAG = "ForegroundService";
    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "SmartMirrorChannel";
    private boolean isRunning = false;
    private ServerSocket serverSocket;
    private int port = 8080;

    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        public ForegroundService getService() {
            return ForegroundService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public boolean isServerRunning() {
        return isRunning;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Сервис создан");
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Сервис запущен");

        Notification notification = createNotification();
        startForeground(NOTIFICATION_ID, notification);

        if (!isRunning) {
            isRunning = true;
            startServer();
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "Ошибка при закрытии сервера", e);
        }
        Log.d(TAG, "Сервис остановлен");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Smart Mirror Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Smart Mirror")
                .setContentText("Сервер запущен и ожидает подключения")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port);
                Log.d(TAG, "Сервер запущен на порту: " + port);

                while (isRunning) {
                    try {
                        Socket clientSocket = serverSocket.accept();
                        Log.d(TAG, "Подключение принято от: " + clientSocket.getInetAddress());
                        handleClientConnection(clientSocket);
                    } catch (Exception e) {
                        if (isRunning) {
                            Log.e(TAG, "Ошибка при принятии подключения", e);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Ошибка запуска сервера", e);
                isRunning = false;
            }
        }).start();
    }

    private void handleClientConnection(Socket clientSocket) {
        new Thread(() -> {
            try {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream()));

                StringBuilder request = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null && !line.isEmpty()) {
                    request.append(line).append("\n");
                }

                String requestBody = request.toString().trim();
                Log.d(TAG, "📨 Получены RAW данные: " + requestBody);

                processReceivedData(requestBody);
                clientSocket.close();

            } catch (Exception e) {
                Log.e(TAG, "Ошибка обработки подключения", e);
            }
        }).start();
    }

    private void processReceivedData(String data) {
        try {
            if (data == null || data.isEmpty()) {
                Log.w(TAG, "Получены пустые данные");
                return;
            }

            Log.d(TAG, "🔍 Анализ входящих данных...");

            // Проверяем, не является ли это командой
            if (data.contains("\"type\":\"command\"")) {
                try {
                    JSONObject commandJson = new JSONObject(data);
                    String action = commandJson.optString("action", "");
                    if ("update_widgets".equals(action)) {
                        Log.d(TAG, "🔄 Получена команда обновления виджетов");
                        updateAllWidgets();
                        return;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Ошибка обработки команды", e);
                }
            }

            RemoteWidget widget = parseWidgetData(data);
            if (widget != null) {
                Log.d(TAG, "🎯 Успешно распознан виджет: " + widget.getType() + " - " + widget.getTitle());
                saveWidgetData(widget);

                // ОБНОВЛЯЕМ виджеты
                updateSpecificWidget(widget.getType());

                // АВТОМАТИЧЕСКИ предлагаем добавить виджет с БОЛЬШОЙ задержкой
                scheduleWidgetPin(widget);

                sendBroadcastToUI(widget);
            } else {
                Log.w(TAG, "❌ Не удалось распознать данные как виджет");
            }

        } catch (Exception e) {
            Log.e(TAG, "Ошибка обработки полученных данных", e);
        }
    }

    private RemoteWidget parseWidgetData(String data) {
        try {
            JSONObject json = new JSONObject(data);
            String type = json.optString("type", "unknown").toLowerCase();
            String title = json.optString("title", "Виджет");
            String widgetData = json.optString("data", "");
            String info = json.optString("additionalInfo", "");

            Log.d(TAG, "📊 Парсинг JSON: type=" + type + ", title=" + title + ", data=" + widgetData);

            // ВАЖНО: Проверяем, что тип корректен
            if (!isValidWidgetType(type)) {
                Log.w(TAG, "⚠️ Неизвестный тип виджета: " + type);
                type = detectWidgetType(data, json);
            }

            return new RemoteWidget(type, title, widgetData, info);
        } catch (Exception e) {
            Log.w(TAG, "❌ Данные не в JSON формате, пытаемся определить тип автоматически");
            String detectedType = detectWidgetType(data, null);
            Log.d(TAG, "🔍 Автоопределение типа: " + detectedType);
            return new RemoteWidget(detectedType, "Полученные данные",
                    data.length() > 100 ? data.substring(0, 100) + "..." : data, "raw");
        }
    }

    private boolean isValidWidgetType(String type) {
        return "weather".equals(type) || "currency".equals(type) ||
                "note".equals(type) || "text".equals(type);
    }

    private String detectWidgetType(String data, JSONObject json) {
        if (json != null) {
            // Пробуем определить по содержимому additionalInfo
            String additionalInfo = json.optString("additionalInfo", "").toLowerCase();
            if (additionalInfo.contains("\"text\"") || additionalInfo.contains("\"color\"") || additionalInfo.contains("\"type\":\"note\"")) {
                return "note";
            }

            String mainType = json.optString("type", "").toLowerCase();
            if ("note".equals(mainType)) {
                return "note";
            }
        }

        data = data.toLowerCase();

        if (data.contains("weather") || data.contains("погод") || data.contains("temperature") ||
                data.contains("temp") || data.contains("°c") || data.contains("°f")) {
            return "weather";
        } else if (data.contains("currency") || data.contains("валют") || data.contains("exchange") ||
                data.contains("usd") || data.contains("eur") || data.contains("rub") ||
                data.contains("доллар") || data.contains("евро")) {
            return "currency";
        } else if (data.contains("note") || data.contains("заметк") || data.contains("текст") ||
                data.contains("text") || data.contains("\"type\":\"note\"")) {
            return "note";
        } else {
            return "note";
        }
    }

    private void saveWidgetData(RemoteWidget widget) {
        android.content.SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = prefs.edit();

        String type = widget.getType();
        String baseKey = "widget_" + type;

        editor.putString(baseKey + "_title", widget.getTitle());
        editor.putString(baseKey + "_data", widget.getData());
        editor.putString(baseKey + "_info", widget.getAdditionalInfo());
        editor.putLong(baseKey + "_timestamp", System.currentTimeMillis());

        editor.putString("last_received_type", type);

        Log.d(TAG, "💾 Сохранение данных виджета типа: " + type);

        if ("weather".equals(type)) {
            parseAndSaveWeatherData(widget, editor);
        } else if ("note".equals(type) || "text".equals(type)) {
            parseAndSaveNoteData(widget, editor);
        }

        editor.apply();

        Log.d(TAG, "✅ Данные сохранены: " + baseKey + ", title: " + widget.getTitle());
    }

    private void parseAndSaveNoteData(RemoteWidget widget, android.content.SharedPreferences.Editor editor) {
        try {
            String additionalInfo = widget.getAdditionalInfo();
            Log.d(TAG, "📝 Начало парсинга данных заметки");

            if (additionalInfo != null && !additionalInfo.isEmpty()) {
                JSONObject json = new JSONObject(additionalInfo);

                String noteText = json.optString("text", widget.getData());
                String backgroundColor = json.optString("color", "#000000");
                String noteType = json.optString("type", "note");

                Log.d(TAG, "✅ Извлеченные данные: текст=" + noteText + ", цвет=" + backgroundColor);

                editor.putString("note_text", noteText);
                editor.putString("note_background", backgroundColor);
                editor.putString("note_type", noteType);
                editor.putString("widget_note_title", widget.getTitle());

            } else {
                Log.d(TAG, "⚠️ AdditionalInfo пустой, сохраняем базовые данные");
                editor.putString("note_text", widget.getData());
                editor.putString("note_background", "#000000");
                editor.putString("widget_note_title", widget.getTitle());
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка парсинга данных заметки", e);
            editor.putString("note_text", widget.getData());
            editor.putString("note_background", "#000000");
            editor.putString("widget_note_title", widget.getTitle());
        }
    }

    private void parseAndSaveWeatherData(RemoteWidget widget, android.content.SharedPreferences.Editor editor) {
        try {
            String additionalInfo = widget.getAdditionalInfo();
            if (additionalInfo != null && !additionalInfo.isEmpty()) {
                JSONObject json = new JSONObject(additionalInfo);

                String description = json.optString("description", "");
                String icon = json.optString("icon", "01d");
                double windSpeed = json.optDouble("wind_speed", 0);
                int humidity = json.optInt("humidity", 0);
                int pressure = json.optInt("pressure", 0);
                String city = json.optString("city", "");

                editor.putString("weather_city", !city.isEmpty() ? city : extractCityFromTitle(widget.getTitle()));
                editor.putString("weather_temp", widget.getData());
                editor.putString("weather_description", description);
                editor.putString("weather_icon", icon);
                editor.putString("weather_wind", String.format("%.1f м/с", windSpeed));
                editor.putInt("weather_humidity", humidity);
                editor.putInt("weather_pressure", pressure);

                String iconUrl = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
                editor.putString("weather_icon_url", iconUrl);

                if (json.has("forecast")) {
                    JSONArray forecastArray = json.getJSONArray("forecast");
                    for (int i = 0; i < Math.min(3, forecastArray.length()); i++) {
                        JSONObject forecastItem = forecastArray.getJSONObject(i);
                        String time = forecastItem.optString("time", "");
                        int temp = forecastItem.optInt("temp", 0);
                        String forecastIcon = forecastItem.optString("icon", "01d");
                        String forecastIconUrl = "https://openweathermap.org/img/wn/" + forecastIcon + ".png";

                        editor.putString("forecast_" + (i + 1) + "_time", time);
                        editor.putString("forecast_" + (i + 1) + "_temp", temp + "°");
                        editor.putString("forecast_" + (i + 1) + "_icon", forecastIcon);
                        editor.putString("forecast_" + (i + 1) + "_icon_url", forecastIconUrl);
                    }
                }

                Log.d(TAG, "🌤️ Данные погоды сохранены");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка парсинга данных погоды", e);
        }
    }

    private String extractCityFromTitle(String title) {
        if (title.startsWith("Погода в ")) {
            return title.substring("Погода в ".length());
        }
        return "Город";
    }

    // НОВЫЙ МЕТОД: Планируем добавление виджета с большой задержкой
    private void scheduleWidgetPin(RemoteWidget widget) {
        String type = widget.getType();
        Log.d(TAG, "🎯 Планируем автоматическое закрепление виджета типа: " + type);

        // Запускаем в отдельном потоке с БОЛЬШОЙ задержкой
        new Thread(() -> {
            try {
                // БОЛЬШАЯ ЗАДЕРЖКА - даем время всем операциям завершиться
                Log.d(TAG, "⏳ Ожидание 3 секунды перед показом диалога...");
                Thread.sleep(3000);

                Class<?> widgetClass = getWidgetClassByType(type);
                if (widgetClass != null) {
                    Log.d(TAG, "✅ Запрашиваем виджет: " + widgetClass.getSimpleName());
                    requestWidgetPin(widgetClass);
                }
            } catch (Exception e) {
                Log.e(TAG, "❌ Ошибка при планировании закрепления виджета", e);
            }
        }).start();
    }

    private Class<?> getWidgetClassByType(String widgetType) {
        switch (widgetType) {
            case "weather":
                return WeatherWidget.class;
            case "currency":
                return CurrencyWidget.class;
            case "note":
            case "text":
                return NoteWidget.class;
            default:
                return NoteWidget.class;
        }
    }

    private void sendBroadcastToUI(RemoteWidget widget) {
        Intent intent = new Intent("WIDGET_RECEIVED");
        intent.putExtra("widget_title", widget.getTitle());
        intent.putExtra("widget_data", widget.getData());
        intent.putExtra("widget_type", widget.getType());
        sendBroadcast(intent);

        String message = "Получен виджет: " + widget.getType();
        if (!widget.getTitle().isEmpty()) {
            message += " - " + widget.getTitle();
        }
        showToast(message);
    }

    public void requestWidgetPin(Class<?> widgetClass) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AppWidgetManager appWidgetManager = getSystemService(AppWidgetManager.class);
                ComponentName widgetProvider = new ComponentName(this, widgetClass);

                if (appWidgetManager.isRequestPinAppWidgetSupported()) {
                    Log.d(TAG, "📌 Запрос на добавление виджета: " + widgetClass.getSimpleName());

                    // Создаем callback для обработки результата
                    Intent callbackIntent = new Intent(this, WidgetPinReceiver.class);
                    callbackIntent.putExtra("widget_type", widgetClass.getSimpleName());

                    PendingIntent successCallback = null;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        successCallback = PendingIntent.getBroadcast(this, 0, callbackIntent,
                                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
                    } else {
                        successCallback = PendingIntent.getBroadcast(this, 0, callbackIntent,
                                PendingIntent.FLAG_UPDATE_CURRENT);
                    }

                    // СОЗДАЕМ ФИНАЛЬНЫЕ ПЕРЕМЕННЫЕ для использования в лямбда-выражении
                    final AppWidgetManager finalAppWidgetManager = appWidgetManager;
                    final ComponentName finalWidgetProvider = widgetProvider;
                    final PendingIntent finalSuccessCallback = successCallback;
                    final Class<?> finalWidgetClass = widgetClass;

                    // ВЫПОЛНЯЕМ В ГЛАВНОМ ПОТОКЕ с дополнительной задержкой
                    runOnUiThreadDelayed(() -> {
                        try {
                            Log.d(TAG, "🔄 Вызов системного диалога добавления виджета...");
                            boolean success = finalAppWidgetManager.requestPinAppWidget(finalWidgetProvider, null, finalSuccessCallback);
                            Log.d(TAG, "✅ Запрос на добавление виджета отправлен: " + success);

                            if (success) {
                                String widgetName = getWidgetDisplayName(finalWidgetClass);
                                showToast("Разрешите добавление виджета " + widgetName + " в появившемся окне");
                                Log.d(TAG, "🎯 Системный диалог должен появиться сейчас");
                            } else {
                                showToast("Не удалось запросить добавление виджета");
                                Log.e(TAG, "❌ Не удалось вызвать системный диалог");
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "❌ Ошибка при вызове requestPinAppWidget", e);
                            showToast("Ошибка при добавлении виджета");
                        }
                    }, 500); // Дополнительная задержка 500ms в UI потоке

                } else {
                    Log.w(TAG, "❌ Добавление виджетов не поддерживается");
                    showToast("Добавление виджетов не поддерживается на этом устройстве");
                }
            } else {
                Log.w(TAG, "❌ Для автоматического добавления нужен Android 8.0+");
                showToast("Для автоматического добавления нужен Android 8.0+");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Критическая ошибка при запросе добавления виджета", e);
            showToast("Ошибка добавления виджета");
        }
    }

    // Вспомогательный метод для запуска кода в UI потоке с задержкой
    private void runOnUiThreadDelayed(Runnable action, long delayMillis) {
        android.os.Handler handler = new android.os.Handler(getMainLooper());
        handler.postDelayed(action, delayMillis);
    }

    // Вспомогательный метод для запуска кода в UI потоке
    private void runOnUiThread(Runnable action) {
        android.os.Handler handler = new android.os.Handler(getMainLooper());
        handler.post(action);
    }

    private String getWidgetDisplayName(Class<?> widgetClass) {
        if (widgetClass == WeatherWidget.class) return "Погоды";
        if (widgetClass == CurrencyWidget.class) return "Валют";
        if (widgetClass == NoteWidget.class) return "Заметки";
        return "Неизвестный";
    }

    // Метод для вызова из MainActivity (ручное добавление)
    public void pinWidgetManual(Class<?> widgetClass) {
        requestWidgetPin(widgetClass);
    }

    private void updateSpecificWidget(String widgetType) {
        Log.d(TAG, "🔄 Запуск обновления виджета: " + widgetType);

        switch (widgetType) {
            case "note":
            case "text":
                updateNoteWidgets();
                break;
            case "weather":
                updateWeatherWidgets();
                break;
            case "currency":
                updateCurrencyWidgets();
                break;
            default:
                updateAllWidgets();
                break;
        }
    }

    private void updateNoteWidgets() {
        try {
            Intent intent = new Intent(this, NoteWidget.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            int[] ids = AppWidgetManager.getInstance(this)
                    .getAppWidgetIds(new ComponentName(this, NoteWidget.class));

            if (ids.length > 0) {
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                sendBroadcast(intent);
                Log.d(TAG, "✅ Виджеты заметок обновлены: " + ids.length + " шт.");
            } else {
                Log.w(TAG, "⚠️ Виджеты заметок не найдены на домашнем экране");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка обновления виджетов заметок", e);
        }
    }

    // Вспомогательный метод для показа Toast из любого потока
    private void showToast(String message) {
        android.os.Handler handler = new android.os.Handler(getMainLooper());
        handler.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    // Метод для принудительного обновления всех виджетов
    public void updateAllWidgets() {
        try {
            updateWeatherWidgets();
            updateCurrencyWidgets();
            updateNoteWidgets();
            Log.d(TAG, "✅ Все виджеты обновлены");
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка при обновлении виджетов", e);
        }
    }

    private void updateWeatherWidgets() {
        try {
            Intent intent = new Intent(this, WeatherWidget.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            int[] ids = AppWidgetManager.getInstance(this)
                    .getAppWidgetIds(new ComponentName(this, WeatherWidget.class));
            if (ids.length > 0) {
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                sendBroadcast(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка обновления виджетов погоды", e);
        }
    }

    private void updateCurrencyWidgets() {
        try {
            Intent intent = new Intent(this, CurrencyWidget.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            int[] ids = AppWidgetManager.getInstance(this)
                    .getAppWidgetIds(new ComponentName(this, CurrencyWidget.class));
            if (ids.length > 0) {
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                sendBroadcast(intent);
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка обновления виджетов валют", e);
        }
    }
}