package com.example.smartsymirror;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.widget.RemoteViews;

public class NoteWidget extends AppWidgetProvider {
    private static final String TAG = "NoteWidget";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные заметки из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String noteText = prefs.getString("note_text", "Ваша заметка появится здесь");
        String backgroundColor = prefs.getString("note_background", "#000000");
        String noteTitle = prefs.getString("widget_note_title", "Заметка");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_note);

        // Устанавливаем текст и цвет
        views.setTextViewText(R.id.note_title, noteTitle);
        views.setTextViewText(R.id.note_text, noteText);

        // Устанавливаем цвет фона
        try {
            int color = Color.parseColor(backgroundColor);
            views.setInt(R.id.note_layout, "setBackgroundColor", color);

            // Меняем цвет текста в зависимости от фона для лучшей читаемости
            int textColor = getContrastColor(color);
            views.setTextColor(R.id.note_title, textColor);
            views.setTextColor(R.id.note_text, textColor);

        } catch (Exception e) {
            // Если цвет некорректный, используем черный фон и белый текст
            views.setInt(R.id.note_layout, "setBackgroundColor", Color.BLACK);
            views.setTextColor(R.id.note_title, Color.WHITE);
            views.setTextColor(R.id.note_text, Color.WHITE);
        }

        // Intent для обновления при нажатии
        Intent updateIntent = new Intent(context, NoteWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(context)
                .getAppWidgetIds(new ComponentName(context, NoteWidget.class));
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);

        PendingIntent pendingUpdateIntent = PendingIntent.getBroadcast(
                context, appWidgetId, updateIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        views.setOnClickPendingIntent(R.id.note_layout, pendingUpdateIntent);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        Log.d(TAG, "Note Widget Updated: " + noteText);
    }

    @Override
    public void onEnabled(Context context) {
        Log.d(TAG, "Note Widget Enabled");
    }

    @Override
    public void onDisabled(Context context) {
        Log.d(TAG, "Note Widget Disabled");
    }

    // Метод для определения контрастного цвета текста
    private static int getContrastColor(int backgroundColor) {
        // Вычисляем яркость цвета по формуле
        double luminance = (0.299 * Color.red(backgroundColor) +
                0.587 * Color.green(backgroundColor) +
                0.114 * Color.blue(backgroundColor)) / 255;

        // Если фон светлый - черный текст, если темный - белый текст
        return luminance > 0.5 ? Color.BLACK : Color.WHITE;
    }

    // Статический метод для принудительного обновления всех виджетов
    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName widgetComponent = new ComponentName(context, NoteWidget.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(widgetComponent);

        Intent updateIntent = new Intent(context, NoteWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds);
        context.sendBroadcast(updateIntent);

        Log.d(TAG, "All Note Widgets Updated");
    }
}