package com.example.smartsymirror;

public class WidgetItem {
    private String type;
    private String title;
    private String data;
    private String additionalInfo;

    public WidgetItem(String type, String title, String data, String additionalInfo) {
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
    }

    public String getType() { return type; }
    public String getTitle() { return title; }
    public String getData() { return data; }
    public String getAdditionalInfo() { return additionalInfo; }
}