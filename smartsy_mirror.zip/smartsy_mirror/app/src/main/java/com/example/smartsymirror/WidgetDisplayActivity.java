package com.example.smartsymirror;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class WidgetDisplayActivity extends AppCompatActivity {
    private static final String TAG = "WidgetDisplayActivity";

    private LinearLayout widgetsContainer;
    private List<WidgetItem> widgetItems = new ArrayList<>();
    private Button testButton, clearButton, refreshButton, backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_display);

        Log.d(TAG, "onCreate: начал работу");

        try {
            initViews();
            setupButtonListeners();
            loadWidgets();
            displayWidgets();
            Log.d(TAG, "onCreate: успешно завершен");
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в onCreate", e);
            Toast.makeText(this, "Ошибка запуска: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void initViews() {
        Log.d(TAG, "initViews: начал работу");
        widgetsContainer = findViewById(R.id.widgetsContainer);
        testButton = findViewById(R.id.testButton);
        clearButton = findViewById(R.id.clearButton);
        refreshButton = findViewById(R.id.refreshButton);
        backButton = findViewById(R.id.backButton);
    }

    private void setupButtonListeners() {
        Log.d(TAG, "setupButtonListeners: настройка слушателей");

        testButton.setOnClickListener(v -> {
            Log.d(TAG, "Нажата тестовая кнопка");
            try {
                addTestWidget();
            } catch (Exception e) {
                Log.e(TAG, "Ошибка в testButton", e);
                Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        clearButton.setOnClickListener(v -> {
            Log.d(TAG, "Нажата кнопка очистки");
            try {
                clearAllWidgets();
            } catch (Exception e) {
                Log.e(TAG, "Ошибка в clearButton", e);
                Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        refreshButton.setOnClickListener(v -> {
            Log.d(TAG, "Нажата кнопка обновления");
            try {
                loadWidgets();
                displayWidgets();
                Toast.makeText(this, "Виджеты обновлены", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Ошибка в refreshButton", e);
                Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        backButton.setOnClickListener(v -> {
            // Возврат к QR активности
            Intent intent = new Intent(this, QRActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: начал работу");
        try {
            loadWidgets();
            displayWidgets();
            Log.d(TAG, "onResume: виджеты обновлены");
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в onResume", e);
        }
    }

    private void loadWidgets() {
        Log.d(TAG, "loadWidgets: начал работу");
        try {
            widgetItems.clear();
            android.content.SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            Map<String, ?> allEntries = prefs.getAll();

            Log.d(TAG, "Всего записей в SharedPreferences: " + allEntries.size());

            if (allEntries.isEmpty()) {
                Log.d(TAG, "SharedPreferences 'remote_widgets' ПУСТЫЕ!");
            }

            int widgetCount = 0;
            for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                String key = entry.getKey();

                if (key.endsWith("_title")) {
                    String baseKey = key.replace("_title", "");
                    String type = prefs.getString(baseKey + "_type", "");
                    String title = prefs.getString(baseKey + "_title", "");
                    String data = prefs.getString(baseKey + "_data", "");
                    String info = prefs.getString(baseKey + "_info", "");
                    long timestamp = prefs.getLong(baseKey + "_timestamp", 0);

                    Log.d(TAG, "Найден виджет: " + title);

                    if (!title.isEmpty()) {
                        WidgetItem widget = new WidgetItem(type, title, data, info);
                        widgetItems.add(widget);
                        widgetCount++;
                    }
                }
            }

            Log.d(TAG, "Итоговое количество виджетов: " + widgetCount);
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в loadWidgets", e);
            throw e;
        }
    }

    private void displayWidgets() {
        Log.d(TAG, "displayWidgets: начал работу");
        try {
            if (widgetsContainer != null) {
                widgetsContainer.removeAllViews();
            } else {
                Log.e(TAG, "widgetsContainer is NULL!");
                return;
            }

            Log.d(TAG, "Количество виджетов для отображения: " + widgetItems.size());

            if (widgetItems.isEmpty()) {
                TextView emptyText = new TextView(this);
                emptyText.setText("Нет полученных виджетов\n\nПодключитесь к основному устройству и отправьте виджеты\n\nИли нажмите кнопку ТЕСТ для проверки");
                emptyText.setTextSize(16);
                emptyText.setPadding(50, 100, 50, 50);
                emptyText.setTextAlignment(android.view.View.TEXT_ALIGNMENT_CENTER);
                emptyText.setTextColor(0xFF666666);
                widgetsContainer.addView(emptyText);
                Log.d(TAG, "❌ Нет виджетов для отображения - показан пустой текст");
                return;
            }

            for (int i = 0; i < widgetItems.size(); i++) {
                WidgetItem widget = widgetItems.get(i);
                Log.d(TAG, "Создание карточки для виджета " + (i + 1) + ": " + widget.getTitle());

                try {
                    LinearLayout cardView = createWidgetCard(widget);
                    widgetsContainer.addView(cardView);
                    Log.d(TAG, "✅ Карточка создана: " + widget.getTitle());
                } catch (Exception e) {
                    Log.e(TAG, "Ошибка создания карточки для виджета: " + widget.getTitle(), e);
                }
            }

            Log.d(TAG, "Итоговое количество отображенных виджетов: " + widgetItems.size());
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в displayWidgets", e);
            throw e;
        }
    }

    private LinearLayout createWidgetCard(WidgetItem widget) {
        try {
            LinearLayout cardLayout = new LinearLayout(this);
            cardLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            cardParams.setMargins(0, 0, 0, 16);
            cardLayout.setLayoutParams(cardParams);

            cardLayout.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
            cardLayout.setPadding(24, 24, 24, 24);

            TextView titleText = new TextView(this);
            titleText.setText(widget.getTitle());
            titleText.setTextSize(18);
            titleText.setTypeface(null, android.graphics.Typeface.BOLD);
            titleText.setTextColor(0xFF333333);
            titleText.setPadding(0, 0, 0, 8);

            TextView dataText = new TextView(this);
            dataText.setText(widget.getData());
            dataText.setTextSize(24);
            dataText.setTextColor(0xFF2196F3);
            dataText.setPadding(0, 0, 0, 8);

            if (widget.getAdditionalInfo() != null && !widget.getAdditionalInfo().isEmpty()) {
                TextView infoText = new TextView(this);
                infoText.setText(widget.getAdditionalInfo());
                infoText.setTextSize(14);
                infoText.setTextColor(0xFF666666);
                infoText.setPadding(0, 0, 0, 8);
                cardLayout.addView(infoText);
            }

            TextView typeText = new TextView(this);
            typeText.setText("Тип: " + widget.getType());
            typeText.setTextSize(12);
            typeText.setTextColor(0xFF4CAF50);

            cardLayout.addView(titleText);
            cardLayout.addView(dataText);
            cardLayout.addView(typeText);

            return cardLayout;
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в createWidgetCard", e);
            throw e;
        }
    }

    private void addTestWidget() {
        Log.d(TAG, "addTestWidget: начал работу");
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            android.content.SharedPreferences.Editor editor = prefs.edit();

            String baseKey = "test_widget_" + System.currentTimeMillis();

            editor.putString(baseKey + "_type", "test");
            editor.putString(baseKey + "_title", "Тестовый виджет");
            editor.putString(baseKey + "_data", "Тестовые данные 123");
            editor.putString(baseKey + "_info", "Это тестовый виджет для проверки");
            editor.putLong(baseKey + "_timestamp", System.currentTimeMillis());

            editor.apply();

            Log.d(TAG, "✅ Тестовый виджет добавлен в SharedPreferences");

            loadWidgets();
            displayWidgets();

            // Автоматически добавляем виджеты на домашний экран
            Intent widgetIntent = new Intent(this, WidgetReceiver.class);
            widgetIntent.setAction("WIDGET_RECEIVED");
            sendBroadcast(widgetIntent);

            Toast.makeText(this, "Тестовый виджет добавлен", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в addTestWidget", e);
            throw e;
        }
    }

    private void clearAllWidgets() {
        Log.d(TAG, "clearAllWidgets: начал работу");
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("remote_widgets", MODE_PRIVATE);
            android.content.SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            Log.d(TAG, "✅ Все виджеты очищены из SharedPreferences");

            widgetItems.clear();
            displayWidgets();

            Toast.makeText(this, "Все виджеты очищены", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Ошибка в clearAllWidgets", e);
            throw e;
        }
    }
}