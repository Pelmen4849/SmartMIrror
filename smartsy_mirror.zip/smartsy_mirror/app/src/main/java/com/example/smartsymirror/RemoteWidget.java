package com.example.smartsymirror;

public class RemoteWidget {
    private String type;
    private String title;
    private String data;
    private String additionalInfo;
    private long timestamp;

    public RemoteWidget(String type, String title, String data, String additionalInfo) {
        this.type = type;
        this.title = title;
        this.data = data;
        this.additionalInfo = additionalInfo;
        this.timestamp = System.currentTimeMillis();
    }

    // Геттеры
    public String getType() { return type; }
    public String getTitle() { return title; }
    public String getData() { return data; }
    public String getAdditionalInfo() { return additionalInfo; }
    public long getTimestamp() { return timestamp; }

    // Сеттеры
    public void setType(String type) { this.type = type; }
    public void setTitle(String title) { this.title = title; }
    public void setData(String data) { this.data = data; }
    public void setAdditionalInfo(String additionalInfo) { this.additionalInfo = additionalInfo; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    @Override
    public String toString() {
        return "RemoteWidget{" +
                "type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", data='" + data + '\'' +
                ", additionalInfo='" + additionalInfo + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}