package com.example.smartsymirror;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.format.Formatter;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView ipAddressText, statusText, widgetsText;
    private Button startServiceBtn, stopServiceBtn, showQrBtn;
    private ForegroundService foregroundService;
    private boolean isServiceBound = false;
    private String ipAddress;
    private int widgetCount = 0;

    private static final String TAG = "SmartMirror";

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            ForegroundService.LocalBinder binder = (ForegroundService.LocalBinder) service;
            foregroundService = binder.getService();
            isServiceBound = true;
            updateUI();
            Log.d(TAG, "Service connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isServiceBound = false;
            foregroundService = null;
            Log.d(TAG, "Service disconnected");
        }
    };

    private BroadcastReceiver widgetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("WIDGET_RECEIVED".equals(intent.getAction())) {
                String widgetTitle = intent.getStringExtra("widget_title");
                String widgetData = intent.getStringExtra("widget_data");
                String widgetType = intent.getStringExtra("widget_type");
                widgetCount++;
                updateWidgetsDisplay();

                // Показываем уведомление о новом виджете
                String message = "Получен виджет: " + widgetType + "\n" + widgetTitle + "\n" + widgetData;
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

                // Обновляем статус
                statusText.setText("Получен новый виджет: " + widgetType);

                Log.d(TAG, "Broadcast received - Widget: " + widgetType + ", Count: " + widgetCount);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "App started");

        initViews();
        setupListeners();
        getIpAddress();

        // Регистрируем приемник broadcast'ов с учетом версии Android
        registerWidgetReceiver();

        // Запускаем сервис автоматически
        startForegroundService();
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerWidgetReceiver() {
        IntentFilter filter = new IntentFilter("WIDGET_RECEIVED");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Для Android 13+ требуется явно указать флаг
            registerReceiver(widgetReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            // Для старых версий Android
            registerReceiver(widgetReceiver, filter);
        }

        Log.d(TAG, "Widget receiver registered");
    }

    private void initViews() {
        ipAddressText = findViewById(R.id.ipAddressText);
        statusText = findViewById(R.id.statusText);
        widgetsText = findViewById(R.id.widgetsText);
        startServiceBtn = findViewById(R.id.startServiceBtn);
        stopServiceBtn = findViewById(R.id.stopServiceBtn);
        showQrBtn = findViewById(R.id.showQrBtn);

        Log.d(TAG, "Views initialized");
    }

    private void setupListeners() {
        startServiceBtn.setOnClickListener(v -> {
            Log.d(TAG, "Start service clicked");
            startForegroundService();
        });

        stopServiceBtn.setOnClickListener(v -> {
            Log.d(TAG, "Stop service clicked");
            stopForegroundService();
        });

        showQrBtn.setOnClickListener(v -> {
            Log.d(TAG, "Show QR clicked");
            showQRCode();
        });

        Log.d(TAG, "Listeners setup");
    }

    private void getIpAddress() {
        try {
            WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifiManager != null && wifiManager.isWifiEnabled()) {
                int ipAddressInt = wifiManager.getConnectionInfo().getIpAddress();
                ipAddress = Formatter.formatIpAddress(ipAddressInt);
                ipAddressText.setText("IP: " + ipAddress + ":8080");
                Log.d(TAG, "IP address: " + ipAddress);
            } else {
                ipAddressText.setText("Wi-Fi не доступен");
                Log.e(TAG, "WiFi not available");
            }
        } catch (Exception e) {
            ipAddressText.setText("Ошибка получения IP");
            Log.e(TAG, "Error getting IP: " + e.getMessage());
        }
    }

    private void startForegroundService() {
        Intent intent = new Intent(this, ForegroundService.class);

        // Для Android 8.0+ используем startForegroundService
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }

        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        statusText.setText("Сервер запущен в фоне");
        Toast.makeText(this, "Сервер запущен", Toast.LENGTH_SHORT).show();

        Log.d(TAG, "Foreground service started");
    }

    private void stopForegroundService() {
        if (isServiceBound) {
            unbindService(serviceConnection);
            isServiceBound = false;
        }

        Intent intent = new Intent(this, ForegroundService.class);
        stopService(intent);

        statusText.setText("Сервер остановлен");
        Toast.makeText(this, "Сервер остановлен", Toast.LENGTH_SHORT).show();

        Log.d(TAG, "Foreground service stopped");
    }

    private void showQRCode() {
        if (ipAddress == null || ipAddress.equals("0.0.0.0")) {
            Toast.makeText(this, "IP-адрес не доступен", Toast.LENGTH_SHORT).show();
            return;
        }

        String connectionString = ipAddress + ":8080";

        // Всегда показываем QR-код в диалоге
        showQRDialog(connectionString);

        Log.d(TAG, "QR code shown for: " + connectionString);
    }

    private void showQRDialog(String connectionString) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("QR-код для подключения");
        builder.setMessage("Адрес для подключения:\n\n" + connectionString + "\n\nСервер работает в фоновом режиме и автоматически принимает виджеты");

        builder.setPositiveButton("Обновить IP", (dialog, which) -> {
            getIpAddress();
            showQRCode(); // Показать с новым IP
        });

        builder.setNegativeButton("Скопировать", (dialog, which) -> {
            // Копирование в буфер обмена
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("IP Address", connectionString);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(this, "Адрес скопирован", Toast.LENGTH_SHORT).show();
        });

        builder.setNeutralButton("Закрыть", null);

        builder.show();
    }

    private void updateUI() {
        boolean isRunning = isServiceBound && foregroundService != null && foregroundService.isServerRunning();
        startServiceBtn.setEnabled(!isRunning);
        stopServiceBtn.setEnabled(isRunning);
        showQrBtn.setEnabled(isRunning);

        if (isRunning) {
            statusText.setText("Сервер запущен - ожидание подключений");
        } else {
            statusText.setText("Сервер остановлен");
        }

        Log.d(TAG, "UI updated - Service running: " + isRunning);
    }

    private void updateWidgetsDisplay() {
        widgetsText.setText("Получено виджетов: " + widgetCount);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Отписываемся от broadcast'ов
        try {
            unregisterReceiver(widgetReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering receiver", e);
        }

        // Останавливаем только сервис, но не отключаем сервер полностью
        if (isServiceBound) {
            unbindService(serviceConnection);
        }

        Log.d(TAG, "Activity destroyed");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
        updateWidgetsDisplay();
        Log.d(TAG, "Activity resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Activity paused");
    }

    // Метод для обработки входящих сообщений (вызывается извне)
    public void onMessageReceived(String message) {
        if (message == null || foregroundService == null) {
            Toast.makeText(this, "Сервис не доступен", Toast.LENGTH_SHORT).show();
            return;
        }

        message = message.trim().toLowerCase();
        Log.d(TAG, "Message received: " + message);

        switch (message) {
            case "weather":
                try {
                    // Используем правильный метод с одним параметром
                    foregroundService.requestWidgetPin(WeatherWidget.class);
                    Toast.makeText(this, "Запрос на добавление виджета погоды отправлен", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Weather widget request sent");
                } catch (Exception e) {
                    Toast.makeText(this, "Ошибка создания виджета погоды", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Weather widget error: " + e.getMessage());
                }
                break;

            case "currency":
                try {
                    // Используем правильный метод с одним параметром
                    foregroundService.requestWidgetPin(CurrencyWidget.class);
                    Toast.makeText(this, "Запрос на добавление виджета валют отправлен", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Currency widget request sent");
                } catch (Exception e) {
                    Toast.makeText(this, "Ошибка создания виджета валют", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Currency widget error: " + e.getMessage());
                }
                break;

            case "test":
                try {
                    foregroundService.requestWidgetPin(TestWidget.class);
                    Toast.makeText(this, "Запрос на добавление тестового виджета отправлен", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Test widget request sent");
                } catch (Exception e) {
                    Toast.makeText(this, "Ошибка создания тестового виджета", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Test widget error: " + e.getMessage());
                }
                break;

            default:
                Toast.makeText(this, "Неизвестный тип виджета: " + message, Toast.LENGTH_SHORT).show();
                Log.w(TAG, "Unknown widget type: " + message);
                break;
        }
    }

    // Метод для ручного тестирования виджетов
    public void testWidget(String type) {
        if (foregroundService == null) {
            Toast.makeText(this, "Сервис не доступен", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (type.toLowerCase()) {
            case "weather":
                // Создаем тестовые данные для погоды
                android.content.SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
                android.content.SharedPreferences.Editor editor = prefs.edit();
                editor.putString("widget_weather_title", "Москва");
                editor.putString("widget_weather_data", "+15°C");
                editor.putString("widget_weather_info", "Облачно");
                editor.putString("last_received_type", "weather");
                editor.apply();

                foregroundService.requestWidgetPin(WeatherWidget.class);
                Toast.makeText(this, "Тестовый виджет погоды создан", Toast.LENGTH_SHORT).show();
                break;

            case "currency":
                // Создаем тестовые данные для валют
                prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
                editor = prefs.edit();
                editor.putString("widget_currency_title", "USD/RUB");
                editor.putString("widget_currency_data", "90.45");
                editor.putString("widget_currency_info", "+0.5%");
                editor.putString("last_received_type", "currency");
                editor.apply();

                foregroundService.requestWidgetPin(CurrencyWidget.class);
                Toast.makeText(this, "Тестовый виджет валют создан", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}