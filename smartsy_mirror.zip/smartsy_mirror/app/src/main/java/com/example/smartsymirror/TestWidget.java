package com.example.smartsymirror;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class TestWidget extends AppWidgetProvider {
    private static final String TAG = "TestWidget";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateTestWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateTestWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String title = prefs.getString("widget_text_title", "Тестовый виджет");
        String data = prefs.getString("widget_text_data", "Данные не получены");
        String info = prefs.getString("widget_text_info", "Ожидание данных...");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.test_widget_layout);

        // Устанавливаем данные
        views.setTextViewText(R.id.test_title, title);
        views.setTextViewText(R.id.test_data, data);
        views.setTextViewText(R.id.test_info, info);

        // Обработчик нажатия для обновления
        Intent updateIntent = new Intent(context, TestWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});

        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.test_layout, updatePendingIntent);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Test Widget Updated: " + title);
    }

    @Override
    public void onEnabled(Context context) {
        android.util.Log.d(TAG, "Test Widget Enabled");
    }

    @Override
    public void onDisabled(Context context) {
        android.util.Log.d(TAG, "Test Widget Disabled");
    }
}