package com.example.smartsymirror;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import androidx.annotation.RequiresApi;
import java.util.Map;

public class WidgetReceiver extends BroadcastReceiver {
    private static final String TAG = "WidgetReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "📨 Получено событие: " + intent.getAction());

        if ("WIDGET_RECEIVED".equals(intent.getAction())) {
            handleWidgetReceived(context);
        } else if (intent.getAction() != null && intent.getAction().startsWith("WIDGET_ADDED_")) {
            handleWidgetAdded(context, intent);
        } else if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            updateAllWidgets(context);
        }
    }

    private void handleWidgetReceived(Context context) {
        Log.d(TAG, "🔄 Обработка полученных виджетов");

        // Сначала обновляем существующие виджеты
        updateAllWidgets(context);

        // Затем проверяем нужно ли добавлять новые виджеты
        checkAndAddNewWidgets(context);
    }

    private void checkAndAddNewWidgets(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        // ПРОВЕРЯЕМ КОНКРЕТНЫЕ КЛЮЧИ, А НЕ СОДЕРЖАНИЕ
        boolean hasWeather = prefs.contains("widget_weather_title") ||
                prefs.contains("last_received_type") &&
                        "weather".equals(prefs.getString("last_received_type", ""));

        boolean hasCurrency = prefs.contains("widget_currency_title") ||
                prefs.contains("last_received_type") &&
                        "currency".equals(prefs.getString("last_received_type", ""));

        Log.d(TAG, "🔍 Проверка виджетов: weather=" + hasWeather + ", currency=" + hasCurrency);

        // Автоматически добавляем виджеты если они есть в SharedPreferences
        if (hasWeather) {
            Log.d(TAG, "🌤️ Найден погодный виджет, пробуем добавить");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                autoAddWeatherWidget(context);
            }
        }

        if (hasCurrency) {
            Log.d(TAG, "💵 Найден валютный виджет, пробуем добавить");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                autoAddCurrencyWidget(context);
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void autoAddWeatherWidget(Context context) {
        try {
            AppWidgetManager appWidgetManager = context.getSystemService(AppWidgetManager.class);
            ComponentName weatherWidget = new ComponentName(context, WeatherWidget.class);

            // Проверяем, не добавлен ли уже виджет
            int[] existingIds = appWidgetManager.getAppWidgetIds(weatherWidget);
            if (existingIds.length > 0) {
                Log.d(TAG, "✅ Погодный виджет уже добавлен на домашний экран");
                return;
            }

            if (appWidgetManager.isRequestPinAppWidgetSupported()) {
                Log.d(TAG, "🔄 Автоматическое добавление погодного виджета");

                Intent callbackIntent = new Intent(context, WidgetPinReceiver.class);
                callbackIntent.setAction("WIDGET_ADDED_WEATHER");
                PendingIntent successCallback = PendingIntent.getBroadcast(
                        context, 0, callbackIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

                boolean success = appWidgetManager.requestPinAppWidget(weatherWidget, null, successCallback);

                if (success) {
                    Log.d(TAG, "✅ Запрос на добавление погодного виджета отправлен");
                } else {
                    Log.e(TAG, "❌ Не удалось отправить запрос на добавление погодного виджета");
                }
            } else {
                Log.e(TAG, "❌ Автоматическое добавление виджетов не поддерживается на этом устройстве");
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка при автоматическом добавлении погодного виджета", e);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void autoAddCurrencyWidget(Context context) {
        try {
            AppWidgetManager appWidgetManager = context.getSystemService(AppWidgetManager.class);
            ComponentName currencyWidget = new ComponentName(context, CurrencyWidget.class);

            // Проверяем, не добавлен ли уже виджет
            int[] existingIds = appWidgetManager.getAppWidgetIds(currencyWidget);
            if (existingIds.length > 0) {
                Log.d(TAG, "✅ Валютный виджет уже добавлен на домашний экран");
                return;
            }

            if (appWidgetManager.isRequestPinAppWidgetSupported()) {
                Log.d(TAG, "🔄 Автоматическое добавление валютного виджета");

                Intent callbackIntent = new Intent(context, WidgetPinReceiver.class);
                callbackIntent.setAction("WIDGET_ADDED_CURRENCY");
                PendingIntent successCallback = PendingIntent.getBroadcast(
                        context, 1, callbackIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

                boolean success = appWidgetManager.requestPinAppWidget(currencyWidget, null, successCallback);

                if (success) {
                    Log.d(TAG, "✅ Запрос на добавление валютного виджета отправлен");
                } else {
                    Log.e(TAG, "❌ Не удалось отправить запрос на добавление валютного виджета");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка при автоматическом добавлении валютного виджета", e);
        }
    }

    private void updateAllWidgets(Context context) {
        Log.d(TAG, "🔄 Обновление всех виджетов");

        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);

        // Обновляем погодный виджет
        updateWeatherWidgets(context, appWidgetManager);

        // Обновляем валютный виджет
        updateCurrencyWidgets(context, appWidgetManager);
    }

    private void updateWeatherWidgets(Context context, AppWidgetManager appWidgetManager) {
        ComponentName weatherWidget = new ComponentName(context, WeatherWidget.class);
        int[] weatherIds = appWidgetManager.getAppWidgetIds(weatherWidget);

        if (weatherIds.length > 0) {
            Log.d(TAG, "🔄 Обновление погодных виджетов: " + weatherIds.length + " шт.");

            // Принудительно обновляем каждый виджет
            for (int appWidgetId : weatherIds) {
                WeatherWidget.updateAppWidget(context, appWidgetManager, appWidgetId);
            }

            Log.d(TAG, "✅ Погодные виджеты обновлены");
        } else {
            Log.d(TAG, "ℹ️ Погодные виджеты не найдены на домашнем экране");
        }
    }

    private void updateCurrencyWidgets(Context context, AppWidgetManager appWidgetManager) {
        ComponentName currencyWidget = new ComponentName(context, CurrencyWidget.class);
        int[] currencyIds = appWidgetManager.getAppWidgetIds(currencyWidget);

        if (currencyIds.length > 0) {
            Log.d(TAG, "🔄 Обновление валютных виджетов: " + currencyIds.length + " шт.");

            // Принудительно обновляем каждый виджет
            for (int appWidgetId : currencyIds) {
                CurrencyWidget.updateAppWidget(context, appWidgetManager, appWidgetId);
            }

            Log.d(TAG, "✅ Валютные виджеты обновлены");
        } else {
            Log.d(TAG, "ℹ️ Валютные виджеты не найдены на домашнем экране");
        }
    }

    private void handleWidgetAdded(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "✅ Виджет успешно добавлен: " + action);

        if ("WIDGET_ADDED_WEATHER".equals(action)) {
            Log.d(TAG, "✅ Погодный виджет успешно добавлен на домашний экран");
        } else if ("WIDGET_ADDED_CURRENCY".equals(action)) {
            Log.d(TAG, "✅ Валютный виджет успешно добавлен на домашний экран");
        }

        // Обновляем данные в только что добавленном виджете
        updateAllWidgets(context);
    }
}