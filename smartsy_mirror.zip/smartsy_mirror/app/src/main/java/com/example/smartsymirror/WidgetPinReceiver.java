package com.example.smartsymirror;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class WidgetPinReceiver extends BroadcastReceiver {
    private static final String TAG = "WidgetPinReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String widgetType = intent.getStringExtra("widget_type");
        Log.d(TAG, "Виджет добавлен на рабочий стол: " + widgetType);
        Toast.makeText(context, "Виджет " + widgetType + " добавлен!", Toast.LENGTH_SHORT).show();
    }
}