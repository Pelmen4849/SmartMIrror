package com.example.smartsymirror;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class CurrencyWidget extends AppWidgetProvider {
    private static final String TAG = "CurrencyWidget";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateCurrencyWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateCurrencyWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String currencyPair = prefs.getString("widget_currency_title", "USD/RUB");
        String rate = prefs.getString("widget_currency_data", "0.00");
        String change = prefs.getString("widget_currency_info", "0.00%");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.currency_widget);

        // Устанавливаем данные
        views.setTextViewText(R.id.currency_pair, currencyPair);
        views.setTextViewText(R.id.currency_rate, rate);
        views.setTextViewText(R.id.currency_change, change);

        // Обработчик нажатия для обновления
        Intent updateIntent = new Intent(context, CurrencyWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});

        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.currency_layout, updatePendingIntent);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Currency Widget Updated: " + currencyPair + " - " + rate);
    }

    @Override
    public void onEnabled(Context context) {
        android.util.Log.d(TAG, "Currency Widget Enabled");
    }

    @Override
    public void onDisabled(Context context) {
        android.util.Log.d(TAG, "Currency Widget Disabled");
    }

    // Статический метод для обновления виджета
    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String currencyPair = prefs.getString("widget_currency_title", "USD/RUB");
        String rate = prefs.getString("widget_currency_data", "0.00");
        String change = prefs.getString("widget_currency_info", "0.00%");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.currency_widget);

        // Устанавливаем данные
        views.setTextViewText(R.id.currency_pair, currencyPair);
        views.setTextViewText(R.id.currency_rate, rate);
        views.setTextViewText(R.id.currency_change, change);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Currency Widget Static Update: " + currencyPair + " - " + rate);
    }
}