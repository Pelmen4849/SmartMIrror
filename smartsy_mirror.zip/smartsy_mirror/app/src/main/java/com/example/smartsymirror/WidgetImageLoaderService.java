package com.example.smartsymirror;

import android.app.IntentService;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.RemoteViews;

import com.squareup.picasso.Picasso;

// WidgetImageLoaderService.java
public class WidgetImageLoaderService extends IntentService {
    private static final String TAG = "WidgetImageLoader";

    public WidgetImageLoaderService() {
        super("WidgetImageLoaderService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            int appWidgetId = intent.getIntExtra("appWidgetId", 0);
            int imageViewId = intent.getIntExtra("imageViewId", 0);
            String imageUrl = intent.getStringExtra("imageUrl");
            String widgetClass = intent.getStringExtra("widgetClass");

            try {
                // Загружаем изображение через Picasso
                Bitmap bitmap = Picasso.get()
                        .load(imageUrl)
                        .resize(100, 100) // Оптимальный размер для виджета
                        .centerInside()
                        .get();

                if (bitmap != null) {
                    // Обновляем виджет с загруженным изображением
                    updateWidgetWithImage(appWidgetId, imageViewId, bitmap, widgetClass);
                    Log.d(TAG, "✅ Изображение загружено: " + imageUrl);
                }
            } catch (Exception e) {
                Log.e(TAG, "❌ Ошибка загрузки изображения: " + imageUrl, e);
            }
        }
    }

    private void updateWidgetWithImage(int appWidgetId, int imageViewId, Bitmap bitmap, String widgetClass) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
        RemoteViews views = new RemoteViews(getPackageName(), R.layout.weather_widget);

        views.setImageViewBitmap(imageViewId, bitmap);

        // Обновляем конкретный виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        Log.d(TAG, "🔄 Виджет обновлен с изображением: " + imageViewId);
    }
}