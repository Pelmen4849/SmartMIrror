package com.example.smartsymirror;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.widget.RemoteViews;

public class WeatherWidget extends AppWidgetProvider {
    private static final String TAG = "WeatherWidget";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWeatherWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private void updateWeatherWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Получаем данные из SharedPreferences
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String city = prefs.getString("weather_city", "Город");
        String temperature = prefs.getString("weather_temp", "--°C");
        String description = prefs.getString("weather_description", "Обновление...");
        String wind = prefs.getString("weather_wind", "0 м/с");
        String iconUrl = prefs.getString("weather_icon_url", "");

        // Получаем данные прогноза
        String forecastTime1 = prefs.getString("forecast_1_time", "18:00");
        String forecastTemp1 = prefs.getString("forecast_1_temp", "--°");
        String forecastIconUrl1 = prefs.getString("forecast_1_icon_url", "");
        String forecastTime2 = prefs.getString("forecast_2_time", "21:00");
        String forecastTemp2 = prefs.getString("forecast_2_temp", "--°");
        String forecastIconUrl2 = prefs.getString("forecast_2_icon_url", "");
        String forecastTime3 = prefs.getString("forecast_3_time", "00:00");
        String forecastTemp3 = prefs.getString("forecast_3_temp", "--°");
        String forecastIconUrl3 = prefs.getString("forecast_3_icon_url", "");

        // Создаем RemoteViews
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.weather_widget);

        // Устанавливаем основные данные
        views.setTextViewText(R.id.weather_city, city);
        views.setTextViewText(R.id.weather_temperature, temperature);
        views.setTextViewText(R.id.weather_description, description);
        views.setTextViewText(R.id.weather_wind, "Ветер: " + wind);

        // Загружаем основную иконку через Picasso
        if (!iconUrl.isEmpty()) {
            loadImageWithPicasso(context, views, R.id.weather_icon, iconUrl, appWidgetId);
        }

        // Устанавливаем прогноз
        views.setTextViewText(R.id.forecast_time_1, forecastTime1);
        views.setTextViewText(R.id.forecast_temp_1, forecastTemp1);
        views.setTextViewText(R.id.forecast_time_2, forecastTime2);
        views.setTextViewText(R.id.forecast_temp_2, forecastTemp2);
        views.setTextViewText(R.id.forecast_time_3, forecastTime3);
        views.setTextViewText(R.id.forecast_temp_3, forecastTemp3);

        // Загружаем иконки прогноза через Picasso
        if (!forecastIconUrl1.isEmpty()) {
            loadImageWithPicasso(context, views, R.id.forecast_icon_1, forecastIconUrl1, appWidgetId);
        }
        if (!forecastIconUrl2.isEmpty()) {
            loadImageWithPicasso(context, views, R.id.forecast_icon_2, forecastIconUrl2, appWidgetId);
        }
        if (!forecastIconUrl3.isEmpty()) {
            loadImageWithPicasso(context, views, R.id.forecast_icon_3, forecastIconUrl3, appWidgetId);
        }

        // Обработчик нажатия для обновления
        Intent updateIntent = new Intent(context, WeatherWidget.class);
        updateIntent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        updateIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{appWidgetId});

        PendingIntent updatePendingIntent = PendingIntent.getBroadcast(context,
                appWidgetId, updateIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        views.setOnClickPendingIntent(R.id.weather_layout, updatePendingIntent);

        // Обновляем виджет
        appWidgetManager.updateAppWidget(appWidgetId, views);

        android.util.Log.d(TAG, "Weather Widget Updated: " + city + " - " + temperature + " - " + description);
    }

    // Метод для загрузки изображений через Picasso в AppWidget
    private void loadImageWithPicasso(Context context, RemoteViews views, int imageViewId, String imageUrl, int appWidgetId) {
        try {
            // Picasso не работает напрямую с RemoteViews, поэтому используем альтернативный подход
            // Создаем IntentService для загрузки изображения
            Intent loadImageIntent = new Intent(context, WidgetImageLoaderService.class);
            loadImageIntent.putExtra("appWidgetId", appWidgetId);
            loadImageIntent.putExtra("imageViewId", imageViewId);
            loadImageIntent.putExtra("imageUrl", imageUrl);
            loadImageIntent.putExtra("widgetClass", WeatherWidget.class.getName());

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(loadImageIntent);
            } else {
                context.startService(loadImageIntent);
            }

        } catch (Exception e) {
            Log.e(TAG, "❌ Ошибка загрузки изображения: " + imageUrl, e);
        }
    }

    // Статический метод для обновления виджета
    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Аналогично updateWeatherWidget но без Picasso (для простоты)
        SharedPreferences prefs = context.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE);

        String city = prefs.getString("weather_city", "Город");
        String temperature = prefs.getString("weather_temp", "--°C");
        String description = prefs.getString("weather_description", "Обновление...");
        String wind = prefs.getString("weather_wind", "0 м/с");

        // Получаем данные прогноза
        String forecastTime1 = prefs.getString("forecast_1_time", "18:00");
        String forecastTemp1 = prefs.getString("forecast_1_temp", "--°");
        String forecastTime2 = prefs.getString("forecast_2_time", "21:00");
        String forecastTemp2 = prefs.getString("forecast_2_temp", "--°");
        String forecastTime3 = prefs.getString("forecast_3_time", "00:00");
        String forecastTemp3 = prefs.getString("forecast_3_temp", "--°");

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.weather_widget);

        // Устанавливаем данные
        views.setTextViewText(R.id.weather_city, city);
        views.setTextViewText(R.id.weather_temperature, temperature);
        views.setTextViewText(R.id.weather_description, description);
        views.setTextViewText(R.id.weather_wind, "Ветер: " + wind);

        // Устанавливаем прогноз
        views.setTextViewText(R.id.forecast_time_1, forecastTime1);
        views.setTextViewText(R.id.forecast_temp_1, forecastTemp1);
        views.setTextViewText(R.id.forecast_time_2, forecastTime2);
        views.setTextViewText(R.id.forecast_temp_2, forecastTemp2);
        views.setTextViewText(R.id.forecast_time_3, forecastTime3);
        views.setTextViewText(R.id.forecast_temp_3, forecastTemp3);

        appWidgetManager.updateAppWidget(appWidgetId, views);
        Log.d(TAG, "Weather Widget Static Update: " + city + " - " + temperature);
    }
}