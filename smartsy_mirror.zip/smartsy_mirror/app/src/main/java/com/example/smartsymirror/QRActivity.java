package com.example.smartsymirror;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class QRActivity extends AppCompatActivity {

    private ImageView qrImage;
    private TextView connectionText;
    private TextView widgetsStatusText;
    private Button refreshButton;
    private BroadcastReceiver serverStatusReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        qrImage = findViewById(R.id.qrImage);
        connectionText = findViewById(R.id.connectionText);
        widgetsStatusText = findViewById(R.id.widgetsStatusText); // Добавлено
        refreshButton = findViewById(R.id.refreshButton);

        // Инициализация BroadcastReceiver
        initServerStatusReceiver();

        // Запускаем сервис сразу при создании активности
        startServerService();
        generateAndDisplayQRCode();

        // Показываем текущие виджеты
        displayCurrentWidgets();

        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateAndDisplayQRCode();
                displayCurrentWidgets();
            }
        });
    }

    private void initServerStatusReceiver() {
        serverStatusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (action == null) return;

                Log.d("ServerStatus", "Received broadcast: " + action);

                if ("WIDGET_RECEIVED".equals(action)) {
                    runOnUiThread(() -> {
                        String widgetType = intent.getStringExtra("widget_type");
                        String widgetTitle = intent.getStringExtra("widget_title");

                        String message = "Получен виджет: " + widgetType;
                        if (widgetTitle != null && !widgetTitle.isEmpty()) {
                            message += " - " + widgetTitle;
                        }

                        Toast.makeText(QRActivity.this, message, Toast.LENGTH_LONG).show();
                        Log.d("WidgetReceiver", "Получены новые виджеты: " + widgetType);

                        // Обновляем отображение виджетов
                        displayCurrentWidgets();
                    });
                }
            }
        };

        // Регистрируем receiver
        IntentFilter filter = new IntentFilter("WIDGET_RECEIVED");

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    registerReceiver(serverStatusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
                } else {
                    registerReceiver(serverStatusReceiver, filter);
                }
            } else {
                registerReceiver(serverStatusReceiver, filter);
            }
            Log.d("QRActivity", "BroadcastReceiver зарегистрирован");
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка регистрации BroadcastReceiver", e);
        }
    }

    /**
     * Отображение текущих полученных виджетов
     */
    private void displayCurrentWidgets() {
        try {
            SharedPreferences prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE);
            Map<String, ?> allEntries = prefs.getAll();

            StringBuilder widgetsInfo = new StringBuilder();
            widgetsInfo.append("Полученные виджеты:\n\n");

            int widgetCount = 0;

            // Проверяем виджеты по типам
            String[] widgetTypes = {"weather", "currency", "note"};

            for (String type : widgetTypes) {
                String title = prefs.getString("widget_" + type + "_title", null);
                if (title != null && !title.isEmpty()) {
                    widgetCount++;
                    String data = prefs.getString("widget_" + type + "_data", "");
                    String info = prefs.getString("widget_" + type + "_info", "");

                    switch (type) {
                        case "weather":
                            widgetsInfo.append("🌤️ ").append(title).append("\n");
                            widgetsInfo.append("Температура: ").append(data).append("\n");

                            // Дополнительная информация о погоде
                            String city = prefs.getString("weather_city", "");
                            String description = prefs.getString("weather_description", "");
                            if (!city.isEmpty()) {
                                widgetsInfo.append("Город: ").append(city).append("\n");
                            }
                            if (!description.isEmpty()) {
                                widgetsInfo.append(description).append("\n");
                            }
                            break;

                        case "currency":
                            widgetsInfo.append("💵 ").append(title).append("\n");
                            widgetsInfo.append("Курс: ").append(data).append("\n");
                            if (!info.isEmpty()) {
                                widgetsInfo.append(info).append("\n");
                            }
                            break;

                        case "note":
                            widgetsInfo.append("📝 ").append(title).append("\n");
                            String noteText = prefs.getString("note_text", data);
                            String bgColor = prefs.getString("note_background", "#000000");
                            widgetsInfo.append("Текст: ").append(noteText.length() > 50 ?
                                    noteText.substring(0, 50) + "..." : noteText).append("\n");
                            widgetsInfo.append("Цвет: ").append(bgColor).append("\n");
                            break;

                        default:
                            widgetsInfo.append("📱 ").append(title).append("\n");
                            widgetsInfo.append(data).append("\n");
                            break;
                    }
                    widgetsInfo.append("\n");
                }
            }

            // Если виджетов нет
            if (widgetCount == 0) {
                widgetsInfo.append("Нет полученных виджетов\n");
                widgetsInfo.append("Отсканируйте QR-код с основного устройства\n");
                widgetsInfo.append("и отправьте виджеты");
            } else {
                widgetsInfo.append("Всего виджетов: ").append(widgetCount).append("\n");
                widgetsInfo.append("Виджеты автоматически добавятся\nна домашний экран");
            }

            widgetsStatusText.setText(widgetsInfo.toString());

        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка при отображении виджетов", e);
            widgetsStatusText.setText("Ошибка загрузки виджетов");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // При возвращении на экран обновляем статус
        generateAndDisplayQRCode();
        displayCurrentWidgets();
    }

    private void generateAndDisplayQRCode() {
        try {
            String ipAddress = getLocalIpAddress();

            if (ipAddress.equals("0.0.0.0")) {
                connectionText.setText("Ошибка: Не удалось получить IP адрес\nПодключитесь к Wi-Fi");
                Toast.makeText(this, "Подключитесь к Wi-Fi сети", Toast.LENGTH_LONG).show();
                qrImage.setImageBitmap(null);
                return;
            }

            // Формируем данные для QR-кода в правильном формате
            String connectionData = ipAddress + ":8080";

            // Обновляем текст
            connectionText.setText("IP: " + ipAddress + "\nПорт: 8080\nГотов к подключению");

            // Генерируем и отображаем QR-код
            Bitmap qrBitmap = generateQRCode(connectionData, 500);
            if (qrBitmap != null) {
                qrImage.setImageBitmap(qrBitmap);
            } else {
                Toast.makeText(this, "Ошибка создания QR-кода", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка генерации QR-кода", e);
            connectionText.setText("Ошибка генерации QR-кода");
        }
    }

    private void startServerService() {
        try {
            Intent serviceIntent = new Intent(this, ForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            Log.d("QRActivity", "Сервис запущен");
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка запуска сервиса", e);
            Toast.makeText(this, "Ошибка запуска сервера", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Генерация настоящего QR-кода с использованием библиотеки ZXing
     */
    private Bitmap generateQRCode(String text, int size) {
        try {
            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, size, size);
            return bitMatrixToBitmap(bitMatrix);

        } catch (WriterException e) {
            Log.e("QRActivity", "Ошибка генерации QR-кода", e);
            return generateFallbackQRCode(text);
        } catch (Exception e) {
            Log.e("QRActivity", "Неожиданная ошибка генерации QR-кода", e);
            return generateFallbackQRCode(text);
        }
    }

    /**
     * Преобразование BitMatrix в Bitmap
     */
    private Bitmap bitMatrixToBitmap(BitMatrix matrix) {
        try {
            int width = matrix.getWidth();
            int height = matrix.getHeight();
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }

            return bitmap;
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка преобразования BitMatrix", e);
            return null;
        }
    }

    /**
     * Резервный метод для генерации QR-кода если библиотека не работает
     */
    private Bitmap generateFallbackQRCode(String text) {
        try {
            int size = 500;
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap);
            android.graphics.Paint paint = new android.graphics.Paint();

            // Белый фон
            canvas.drawColor(Color.WHITE);

            // Черные углы (упрощенный QR-код)
            paint.setColor(Color.BLACK);
            paint.setStyle(android.graphics.Paint.Style.FILL);

            // Рисуем три квадрата в углах (как в настоящем QR-коде)
            drawQRCorner(canvas, paint, 50, 50, 80);
            drawQRCorner(canvas, paint, size - 130, 50, 80);
            drawQRCorner(canvas, paint, 50, size - 130, 80);

            // Текст с информацией
            paint.setColor(Color.BLACK);
            paint.setTextSize(20f);
            paint.setTextAlign(android.graphics.Paint.Align.CENTER);

            String ip = getLocalIpAddress();
            String[] lines = {
                    "SMART MIRROR",
                    "IP: " + ip,
                    "PORT: 8080"
            };

            float lineHeight = paint.getTextSize() + 10;
            float startY = size - 50;

            for (int i = lines.length - 1; i >= 0; i--) {
                canvas.drawText(lines[i], size / 2, startY - (i * lineHeight), paint);
            }

            return bitmap;

        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка генерации резервного QR-кода", e);
            return null;
        }
    }

    private void drawQRCorner(android.graphics.Canvas canvas, android.graphics.Paint paint,
                              int x, int y, int size) {
        try {
            // Внешний черный квадрат
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(Color.BLACK);
            canvas.drawRect(x, y, x + size, y + size, paint);

            // Внутренний белый квадрат
            paint.setColor(Color.WHITE);
            canvas.drawRect(x + 15, y + 15, x + size - 15, y + size - 15, paint);

            // Внутренний черный квадрат
            paint.setColor(Color.BLACK);
            canvas.drawRect(x + 30, y + 30, x + size - 30, y + size - 30, paint);
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка рисования угла QR-кода", e);
        }
    }

    private String getLocalIpAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface networkInterface : interfaces) {
                String interfaceName = networkInterface.getName().toLowerCase();
                // Ищем WiFi интерфейсы
                if (interfaceName.startsWith("wlan") || interfaceName.startsWith("eth") ||
                        interfaceName.startsWith("ap") || interfaceName.contains("wifi")) {
                    List<InetAddress> addresses = Collections.list(networkInterface.getInetAddresses());
                    for (InetAddress address : addresses) {
                        if (!address.isLoopbackAddress() && address instanceof Inet4Address) {
                            String ip = address.getHostAddress();
                            if (ip != null && !ip.isEmpty()) {
                                Log.d("QRActivity", "Найден IP: " + ip + " на интерфейсе: " + interfaceName);
                                return ip;
                            }
                        }
                    }
                }
            }

            // Если не нашли WiFi, ищем любой IPv4 адрес
            for (NetworkInterface networkInterface : interfaces) {
                List<InetAddress> addresses = Collections.list(networkInterface.getInetAddresses());
                for (InetAddress address : addresses) {
                    if (!address.isLoopbackAddress() && address instanceof Inet4Address) {
                        String ip = address.getHostAddress();
                        if (ip != null && !ip.isEmpty()) {
                            Log.d("QRActivity", "Найден альтернативный IP: " + ip);
                            return ip;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e("QRActivity", "Ошибка получения IP адреса", e);
        }
        return "0.0.0.0";
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serverStatusReceiver != null) {
            try {
                unregisterReceiver(serverStatusReceiver);
                Log.d("QRActivity", "BroadcastReceiver отрегистрирован");
            } catch (Exception e) {
                Log.e("QRActivity", "Ошибка отрегистрации receiver", e);
            }
        }
    }
}